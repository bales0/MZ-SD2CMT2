#include "wav_playback_driver.h"

#include <stddef.h>

#include <Arduino.h>
#include <avr/interrupt.h>
#include <util/atomic.h>

/* Timer5 is intentionally dedicated to WAV playback. */
#if !defined(TIMER5_COMPA_vect)
#error "WAV playback driver requires Timer5 (Arduino Mega 2560 target)"
#endif

/*
    AVR enums normally use int storage. A byte state is deliberately used here
    because it is read in both foreground code and TIMER5_COMPA ISR.
*/
static volatile uint8_t driver_state = WAV_PLAYBACK_DRIVER_STOPPED;

static wav_playback_pop_sample_fn pop_sample_callback = NULL;
static wav_playback_source_finished_fn source_finished_callback = NULL;

static volatile uint32_t timer_rate = 0;
static volatile uint16_t timer_base_ticks = 0;
static volatile uint32_t timer_remainder = 0;
static volatile uint32_t timer_phase = 0;

static volatile uint8_t *read_output_port = NULL;
static uint8_t read_output_mask = 0;

static inline void wav_playback_set_level(uint8_t level)
{
    uint8_t port_value = *read_output_port;
    uint8_t level_mask = (uint8_t)(0U - (level & 1U));

    level_mask &= read_output_mask;

    *read_output_port = (uint8_t)((port_value & (uint8_t)~read_output_mask) |
                                  level_mask);
}

static inline void wav_playback_schedule_next_from_isr(void)
{
    uint16_t ticks = timer_base_ticks;

    /* Bresenham timing: exact long-term sample rate at 16 MHz. */
    timer_phase += timer_remainder;

    if (timer_phase >= timer_rate)
    {
        timer_phase -= timer_rate;
        ticks++;
    }

    OCR5A = (uint16_t)(ticks - 1U);
}

static inline void wav_playback_disable_timer_from_isr(void)
{
    TCCR5B = _BV(WGM52);
    TIMSK5 &= (uint8_t)~_BV(OCIE5A);
    TIFR5 = _BV(OCF5A);
}

static wav_playback_driver_state_t wav_playback_state_snapshot(void)
{
    uint8_t state;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        state = driver_state;
    }

    return (wav_playback_driver_state_t)state;
}

void wav_playback_driver_init(void)
{
    uint8_t port = digitalPinToPort(WAV_PLAYBACK_READ_PIN);

    pinMode(WAV_PLAYBACK_READ_PIN, OUTPUT);
    digitalWrite(WAV_PLAYBACK_READ_PIN, LOW);

    if (port == NOT_A_PIN)
    {
        driver_state = WAV_PLAYBACK_DRIVER_BAD_ARGUMENT;
        return;
    }

    read_output_port = portOutputRegister(port);
    read_output_mask = digitalPinToBitMask(WAV_PLAYBACK_READ_PIN);

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        TCCR5A = 0;
        TCCR5B = _BV(WGM52);
        TCNT5 = 0;
        OCR5A = 0xFFFF;
        TIMSK5 &= (uint8_t)~_BV(OCIE5A);
        TIFR5 = _BV(OCF5A);
    }

    pop_sample_callback = NULL;
    source_finished_callback = NULL;
    timer_rate = 0;
    timer_base_ticks = 0;
    timer_remainder = 0;
    timer_phase = 0;
    driver_state = WAV_PLAYBACK_DRIVER_STOPPED;
}

bool wav_playback_driver_prepare(uint32_t sample_rate,
                                 wav_playback_pop_sample_fn pop_sample,
                                 wav_playback_source_finished_fn source_finished)
{
    uint32_t base_ticks;

    if ((read_output_port == NULL) ||
        (sample_rate == 0) ||
        (pop_sample == NULL) ||
        (source_finished == NULL))
    {
        driver_state = WAV_PLAYBACK_DRIVER_BAD_ARGUMENT;
        return false;
    }

    base_ticks = (uint32_t)F_CPU / sample_rate;

    if ((base_ticks < 2U) || (base_ticks > 65536UL))
    {
        driver_state = WAV_PLAYBACK_DRIVER_BAD_RATE;
        return false;
    }

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        /*
            Important: do not enable OCIE5A in READY state. The old v0.06
            code did so, so a pending OCF5A flag could invoke the ISR before
            SELECT and turn a valid RDY session into ERR.
        */
        TCCR5B = _BV(WGM52);
        TIMSK5 &= (uint8_t)~_BV(OCIE5A);
        TIFR5 = _BV(OCF5A);
        TCNT5 = 0;

        timer_rate = sample_rate;
        timer_base_ticks = (uint16_t)base_ticks;
        timer_remainder = (uint32_t)F_CPU % sample_rate;
        timer_phase = 0;

        OCR5A = (uint16_t)(timer_base_ticks - 1U);

        pop_sample_callback = pop_sample;
        source_finished_callback = source_finished;
        driver_state = WAV_PLAYBACK_DRIVER_READY;
    }

    return true;
}

bool wav_playback_driver_start(void)
{
    uint8_t level;

    if (wav_playback_state_snapshot() != WAV_PLAYBACK_DRIVER_READY)
    {
        return false;
    }

    /* Output sample 0 immediately; the ISR outputs sample 1 one period later. */
    if (!pop_sample_callback(&level))
    {
        driver_state = source_finished_callback() ?
            WAV_PLAYBACK_DRIVER_FINISHED : WAV_PLAYBACK_DRIVER_UNDERRUN;
        return false;
    }

    wav_playback_set_level(level);

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        TCNT5 = 0;
        timer_phase = 0;
        OCR5A = (uint16_t)(timer_base_ticks - 1U);

        /* Clear stale compare state before unmasking the IRQ and clocking T5. */
        TIFR5 = _BV(OCF5A);
        driver_state = WAV_PLAYBACK_DRIVER_RUNNING;
        TIMSK5 |= _BV(OCIE5A);
        TCCR5B = _BV(WGM52) | _BV(CS50);
    }

    return true;
}

bool wav_playback_driver_pause(void)
{
    if (wav_playback_state_snapshot() != WAV_PLAYBACK_DRIVER_RUNNING)
    {
        return false;
    }

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        TCCR5B = _BV(WGM52);
        TIMSK5 &= (uint8_t)~_BV(OCIE5A);
        TIFR5 = _BV(OCF5A);
        driver_state = WAV_PLAYBACK_DRIVER_PAUSED;
    }

    return true;
}

bool wav_playback_driver_resume(void)
{
    if (wav_playback_state_snapshot() != WAV_PLAYBACK_DRIVER_PAUSED)
    {
        return false;
    }

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        TCNT5 = 0;
        TIFR5 = _BV(OCF5A);
        driver_state = WAV_PLAYBACK_DRIVER_RUNNING;
        TIMSK5 |= _BV(OCIE5A);
        TCCR5B = _BV(WGM52) | _BV(CS50);
    }

    return true;
}

void wav_playback_driver_stop(void)
{
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        TCCR5B = _BV(WGM52);
        TIMSK5 &= (uint8_t)~_BV(OCIE5A);
        TIFR5 = _BV(OCF5A);
        driver_state = WAV_PLAYBACK_DRIVER_STOPPED;
    }

    if (read_output_port != NULL)
    {
        *read_output_port &= (uint8_t)~read_output_mask;
    }

    pop_sample_callback = NULL;
    source_finished_callback = NULL;
}

wav_playback_driver_state_t wav_playback_driver_get_state(void)
{
    return wav_playback_state_snapshot();
}

uint32_t wav_playback_driver_get_sample_rate(void)
{
    uint32_t sample_rate;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        sample_rate = timer_rate;
    }

    return sample_rate;
}

uint8_t wav_playback_driver_get_read_pin(void)
{
    return WAV_PLAYBACK_READ_PIN;
}

ISR(TIMER5_COMPA_vect)
{
    uint8_t level;

    if ((driver_state != WAV_PLAYBACK_DRIVER_RUNNING) ||
        (pop_sample_callback == NULL) ||
        (source_finished_callback == NULL))
    {
        wav_playback_disable_timer_from_isr();
        driver_state = WAV_PLAYBACK_DRIVER_BAD_ARGUMENT;
        return;
    }

    if (!pop_sample_callback(&level))
    {
        wav_playback_disable_timer_from_isr();
        driver_state = source_finished_callback() ?
            WAV_PLAYBACK_DRIVER_FINISHED : WAV_PLAYBACK_DRIVER_UNDERRUN;
        return;
    }

    wav_playback_set_level(level);
    wav_playback_schedule_next_from_isr();
}
