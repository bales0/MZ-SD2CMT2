#ifndef SD2CMT2_WAV_SAMPLE_STREAM_H
#define SD2CMT2_WAV_SAMPLE_STREAM_H

#include <stdbool.h>
#include <stdint.h>

#include "../formats/wav_reader.h"

/*
    Packed prepared logical READ levels.

    Each WAV sample has already passed threshold + hysteresis and is stored as
    a single bit. 2048 SRAM bytes therefore hold 16383 output samples:

    - 742.8 ms at 22050 Hz
    - 371.5 ms at 44100 Hz
    - 341.3 ms at 48000 Hz

    This is deliberately far larger than the old byte-per-sample buffer while
    using the same SRAM amount. The ISR still only reads one precomputed bit;
    it never accesses SD, parses RIFF, or evaluates thresholds.
*/
#define WAV_SAMPLE_STREAM_BUFFER_BYTES 2048U
#define WAV_SAMPLE_STREAM_CAPACITY_SAMPLES \
    ((WAV_SAMPLE_STREAM_BUFFER_BYTES * 8U) - 1U)

#define WAV_SAMPLE_STREAM_REFILL_BLOCK 512U

typedef struct
{
    uint8_t low_threshold;
    uint8_t high_threshold;
    bool invert_signal;

} wav_sample_stream_config_t;

bool wav_sample_stream_open(const char *path,
                            const wav_sample_stream_config_t *config);

void wav_sample_stream_close(void);

/*
    Read and prepare at most WAV_SAMPLE_STREAM_REFILL_BLOCK samples.
    Call regularly from foreground code while playback is running.
    Never call from a timer ISR.
*/
bool wav_sample_stream_refill_block(void);

/* Fill all currently available free space. Use only before timer start. */
bool wav_sample_stream_prefill(void);

/* Safe for normal foreground code. */
bool wav_sample_stream_pop(uint8_t *level);

/*
    Intended only for the fixed-rate WAV timer ISR. It just dequeues a
    precomputed 0/1 sample. No SD, parsing or threshold/hysteresis is used.
*/
bool wav_sample_stream_pop_from_isr(uint8_t *level);

uint16_t wav_sample_stream_available(void);

bool wav_sample_stream_source_finished(void);

bool wav_sample_stream_finished(void);

/* Only for the timer ISR; no atomic block is entered. */
bool wav_sample_stream_finished_from_isr(void);

const wav_reader_info_t *wav_sample_stream_info(void);

wav_reader_status_t wav_sample_stream_last_status(void);

#endif
