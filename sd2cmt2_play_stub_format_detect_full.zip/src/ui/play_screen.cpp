#include <Arduino.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>

#include "play_screen.h"

#include "../drivers/lcd.h"

#define PLAY_SCREEN_NAME_MAX 64
#define PLAY_SCREEN_PATH_MAX 160

static char selected_filename[PLAY_SCREEN_NAME_MAX];
static char selected_full_path[PLAY_SCREEN_PATH_MAX];
static play_file_format_t selected_format = PLAY_FILE_FORMAT_UNKNOWN;
static menu_play_mode_t selected_play_mode = MENU_PLAY_MODE_NORMAL;
static bool selected_invert_signal = false;

static void lcd_print_fixed(uint8_t row, const char *text)
{
    char line[17];

    snprintf(line, sizeof(line), "%-16s", text != NULL ? text : "");

    lcd_set_cursor(0, row);
    lcd_print(line);
}

static bool chars_equal_ignore_case(char a, char b)
{
    return (char)toupper((unsigned char)a) == (char)toupper((unsigned char)b);
}

static bool extension_equals(const char *filename, const char *extension)
{
    size_t filename_len;
    size_t extension_len;
    const char *filename_extension;

    if ((filename == NULL) || (extension == NULL))
    {
        return false;
    }

    filename_len = strlen(filename);
    extension_len = strlen(extension);

    if (filename_len < extension_len)
    {
        return false;
    }

    filename_extension = filename + filename_len - extension_len;

    for (size_t i = 0; i < extension_len; i++)
    {
        if (!chars_equal_ignore_case(filename_extension[i], extension[i]))
        {
            return false;
        }
    }

    return true;
}

static play_file_format_t detect_format(const char *filename)
{
    if (extension_equals(filename, ".MZF"))
    {
        return PLAY_FILE_FORMAT_MZF;
    }

    if (extension_equals(filename, ".MZT"))
    {
        return PLAY_FILE_FORMAT_MZT;
    }

    if (extension_equals(filename, ".LEP"))
    {
        return PLAY_FILE_FORMAT_LEP;
    }

    if (extension_equals(filename, ".L16"))
    {
        return PLAY_FILE_FORMAT_L16;
    }

    if (extension_equals(filename, ".WAV"))
    {
        return PLAY_FILE_FORMAT_WAV;
    }

    return PLAY_FILE_FORMAT_UNKNOWN;
}

static const char* format_to_label(play_file_format_t format)
{
    switch (format)
    {
        case PLAY_FILE_FORMAT_MZF:
            return "MZF";

        case PLAY_FILE_FORMAT_MZT:
            return "MZT";

        case PLAY_FILE_FORMAT_LEP:
            return "LEP";

        case PLAY_FILE_FORMAT_L16:
            return "L16";

        case PLAY_FILE_FORMAT_WAV:
            return "WAV";

        case PLAY_FILE_FORMAT_UNKNOWN:
        default:
            return "UNKNOWN";
    }
}

static const char* play_mode_to_label(menu_play_mode_t play_mode)
{
    switch (play_mode)
    {
        case MENU_PLAY_MODE_ULTRA_TURBO:
            return "ULTRA";

        case MENU_PLAY_MODE_NORMAL:
        default:
            return "NORMAL";
    }
}

void play_screen_init(
    const char *filename,
    const char *full_path,
    menu_play_mode_t play_mode,
    bool invert_signal
)
{
    if (filename == NULL)
    {
        selected_filename[0] = '\0';
    }
    else
    {
        strncpy(selected_filename, filename, sizeof(selected_filename) - 1);
        selected_filename[sizeof(selected_filename) - 1] = '\0';
    }

    if (full_path == NULL)
    {
        selected_full_path[0] = '\0';
    }
    else
    {
        strncpy(selected_full_path, full_path, sizeof(selected_full_path) - 1);
        selected_full_path[sizeof(selected_full_path) - 1] = '\0';
    }

    selected_play_mode = play_mode;
    selected_invert_signal = invert_signal;
    selected_format = detect_format(selected_filename);
}

play_screen_action_t play_screen_handle_event(button_event_t event)
{
    switch (event)
    {
        case BUTTON_EVENT_LEFT_SHORT:
        case BUTTON_EVENT_LEFT_LONG:
            return PLAY_SCREEN_ACTION_BACK;

        default:
            break;
    }

    return PLAY_SCREEN_ACTION_NONE;
}

void play_screen_render(void)
{
    char line1[17];

    lcd_print_fixed(0, selected_filename);

    if (selected_format == PLAY_FILE_FORMAT_UNKNOWN)
    {
        snprintf(line1, sizeof(line1), "UNSUPPORTED");
    }
    else
    {
        snprintf(
            line1,
            sizeof(line1),
            "%s %s%s",
            format_to_label(selected_format),
            play_mode_to_label(selected_play_mode),
            selected_invert_signal ? " I" : ""
        );
    }

    lcd_print_fixed(1, line1);
}

const char* play_screen_get_filename(void)
{
    return selected_filename;
}

const char* play_screen_get_full_path(void)
{
    return selected_full_path;
}

play_file_format_t play_screen_get_file_format(void)
{
    return selected_format;
}

menu_play_mode_t play_screen_get_play_mode(void)
{
    return selected_play_mode;
}

bool play_screen_get_invert_signal(void)
{
    return selected_invert_signal;
}
