#include "wav_playback_driver.h"

#include <Arduino.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/atomic.h>

#include "mzio.h"
#include "../streams/wav_sample_stream.h"

#if !defined(TIMER1_COMPA_vect)
#error "WAV playback driver requires Timer1 compare A on Arduino Mega 2560"
#endif

/*
    Tight sample-by-sample Timer1 path.

    There are deliberately no callbacks, no function pointers, no 32-bit
    counters and no per-sample jitter statistics in TIMER1_COMPA_vect. At
    44100 Hz the interval is only 362/363 CPU ticks, so those abstractions
    consumed the entire timing budget in v0.12 and starved foreground SD refill.
*/
static volatile uint8_t driver_state = WAV_PLAYBACK_DRIVER_STOPPED;

static volatile uint16_t timer_sample_rate = 0;
static volatile uint16_t timer_base_ticks = 0;
static volatile uint16_t timer_remainder_ticks = 0;
static volatile uint16_t timer_phase_ticks = 0;

static volatile uint8_t next_output_level = 0;
static volatile uint8_t next_output_valid = 0;
static volatile uint16_t emitted_sequence = 0;

static inline __attribute__((always_inline))
void wav_playback_schedule_period_from_isr(void)
{
    uint16_t ticks = timer_base_ticks;
    uint16_t phase = timer_phase_ticks;
    uint16_t threshold = (uint16_t)(
        timer_sample_rate - timer_remainder_ticks
    );

    /*
        This is phase = (phase + remainder) mod rate without a 32-bit divide
        or a 16-bit overflow. It yields only base or base+1 clock ticks.
    */
    if (phase >= threshold)
    {
        phase = (uint16_t)(phase - threshold);
        ticks++;
    }
    else
    {
        phase = (uint16_t)(phase + timer_remainder_ticks);
    }

    timer_phase_ticks = phase;
    OCR1A = (uint16_t)(ticks - 1U);
}

static inline __attribute__((always_inline))
void wav_playback_disable_timer_from_isr(void)
{
    TCCR1B = _BV(WGM12);
    TIMSK1 &= (uint8_t)~_BV(OCIE1A);
    TIFR1 = _BV(OCF1A);

#if WAV_PLAYBACK_TIMING_MARKER_ENABLE
    TCCR1A = 0;
    PORTB &= (uint8_t)~_BV(PB5);
#endif
}

static void wav_playback_disable_timer_from_foreground(void)
{
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        TCCR1B = _BV(WGM12);
        TIMSK1 &= (uint8_t)~_BV(OCIE1A);
        TIFR1 = _BV(OCF1A);

#if WAV_PLAYBACK_TIMING_MARKER_ENABLE
        TCCR1A = 0;
        PORTB &= (uint8_t)~_BV(PB5);
#else
        TCCR1A = 0;
#endif
    }
}

static wav_playback_driver_state_t wav_playback_state_snapshot(void)
{
    uint8_t state;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        state = driver_state;
    }

    return (wav_playback_driver_state_t)state;
}

static void wav_playback_enable_timer_from_foreground(void)
{
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        TCNT1 = 0;
        TIFR1 = _BV(OCF1A);

#if WAV_PLAYBACK_TIMING_MARKER_ENABLE
        TCCR1A = _BV(COM1A0);
#else
        TCCR1A = 0;
#endif

        driver_state = WAV_PLAYBACK_DRIVER_RUNNING;
        TIMSK1 |= _BV(OCIE1A);
        TCCR1B = _BV(WGM12) | _BV(CS10);
    }
}

void wav_playback_driver_init(void)
{
    mzio_init();

#if WAV_PLAYBACK_TIMING_MARKER_ENABLE
    pinMode(WAV_PLAYBACK_TIMING_MARKER_PIN, OUTPUT);
    digitalWrite(WAV_PLAYBACK_TIMING_MARKER_PIN, LOW);
#endif

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        TCCR1A = 0;
        TCCR1B = _BV(WGM12);
        TCNT1 = 0;
        OCR1A = 0xFFFFU;
        TIMSK1 &= (uint8_t)~_BV(OCIE1A);
        TIFR1 = _BV(OCF1A);
    }

    timer_sample_rate = 0;
    timer_base_ticks = 0;
    timer_remainder_ticks = 0;
    timer_phase_ticks = 0;

    next_output_level = 0;
    next_output_valid = 0;
    emitted_sequence = 0;

    driver_state = WAV_PLAYBACK_DRIVER_STOPPED;
}

bool wav_playback_driver_prepare(uint32_t sample_rate)
{
    uint32_t base_ticks;
    uint32_t remainder_ticks;

    if ((sample_rate == 0UL) || (sample_rate > 65535UL))
    {
        driver_state = WAV_PLAYBACK_DRIVER_BAD_ARGUMENT;
        return false;
    }

    base_ticks = (uint32_t)F_CPU / sample_rate;
    remainder_ticks = (uint32_t)F_CPU % sample_rate;

    if ((base_ticks == 0UL) || (base_ticks > 65535UL))
    {
        driver_state = WAV_PLAYBACK_DRIVER_BAD_RATE;
        return false;
    }

    wav_playback_disable_timer_from_foreground();

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        TCNT1 = 0;

        timer_sample_rate = (uint16_t)sample_rate;
        timer_base_ticks = (uint16_t)base_ticks;
        timer_remainder_ticks = (uint16_t)remainder_ticks;
        timer_phase_ticks = 0;

        next_output_level = 0;
        next_output_valid = 0;
        emitted_sequence = 0;

        driver_state = WAV_PLAYBACK_DRIVER_READY;
    }

    mz_read_set(false);
    return true;
}

bool wav_playback_driver_start(void)
{
    uint8_t first_level;

    if (wav_playback_state_snapshot() != WAV_PLAYBACK_DRIVER_READY)
    {
        return false;
    }

    if (!wav_sample_stream_pop_fast_from_isr(&first_level))
    {
        driver_state = wav_sample_stream_finished_fast_from_isr() ?
            WAV_PLAYBACK_DRIVER_FINISHED : WAV_PLAYBACK_DRIVER_UNDERRUN;
        return false;
    }

    /*
        Output sample zero at t=0. The next value is prefetched now so that
        TIMER1_COMPA only has a direct port write before buffer work.
    */
    mz_read_set_fast_from_isr(first_level);
    emitted_sequence = 1U;

    if (wav_sample_stream_pop_fast_from_isr(&first_level))
    {
        next_output_level = first_level;
        next_output_valid = 1U;
    }
    else
    {
        next_output_valid = 0U;
    }

    wav_playback_schedule_period_from_isr();
    wav_playback_enable_timer_from_foreground();

    return true;
}

bool wav_playback_driver_pause(void)
{
    if (wav_playback_state_snapshot() != WAV_PLAYBACK_DRIVER_RUNNING)
    {
        return false;
    }

    wav_playback_disable_timer_from_foreground();

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        driver_state = WAV_PLAYBACK_DRIVER_PAUSED;
    }

    return true;
}

bool wav_playback_driver_resume(void)
{
    if (wav_playback_state_snapshot() != WAV_PLAYBACK_DRIVER_PAUSED)
    {
        return false;
    }

    /*
        Pause holds the last output level. Resume starts a full new interval
        before emitting the already-prefetched following sample.
    */
    wav_playback_schedule_period_from_isr();
    wav_playback_enable_timer_from_foreground();

    return true;
}

void wav_playback_driver_stop(void)
{
    wav_playback_disable_timer_from_foreground();

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        driver_state = WAV_PLAYBACK_DRIVER_STOPPED;
        next_output_valid = 0;
        emitted_sequence = 0;
    }

    mz_read_set(false);
}

wav_playback_driver_state_t wav_playback_driver_get_state(void)
{
    return wav_playback_state_snapshot();
}

uint32_t wav_playback_driver_get_sample_rate(void)
{
    uint16_t sample_rate;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        sample_rate = timer_sample_rate;
    }

    return (uint32_t)sample_rate;
}

uint8_t wav_playback_driver_get_read_pin(void)
{
    return mzio_read_pin();
}

uint16_t wav_playback_driver_get_emitted_sequence(void)
{
    uint16_t sequence;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        sequence = emitted_sequence;
    }

    return sequence;
}

uint16_t wav_playback_driver_get_jitter_ticks(void)
{
    return 0U;
}

ISR(TIMER1_COMPA_vect)
{
    /*
        Keep this ISR below the 362-tick minimum at 44.1 kHz:
        state check -> direct D2 update -> single inline FIFO pop -> fractional
        period schedule. No call through a function pointer and no 32-bit math.
    */
    if (driver_state != WAV_PLAYBACK_DRIVER_RUNNING)
    {
        wav_playback_disable_timer_from_isr();
        driver_state = WAV_PLAYBACK_DRIVER_BAD_ARGUMENT;
        return;
    }

    if (next_output_valid == 0U)
    {
        wav_playback_disable_timer_from_isr();

        if (wav_sample_stream_finished_fast_from_isr())
        {
            mz_read_set_fast_from_isr(0);
            driver_state = WAV_PLAYBACK_DRIVER_FINISHED;
        }
        else
        {
            mz_read_set_fast_from_isr(0);
            driver_state = WAV_PLAYBACK_DRIVER_UNDERRUN;
        }

        return;
    }

    /*
        READ update is the first data-path action in the ISR. D11 is toggled
        in hardware at this same compare event for jitter measurement.
    */
    mz_read_set_fast_from_isr(next_output_level);
    emitted_sequence = (uint16_t)(emitted_sequence + 1U);

    if (!wav_sample_stream_pop_fast_from_isr(
            (uint8_t *)&next_output_level))
    {
        next_output_valid = 0U;
    }

    wav_playback_schedule_period_from_isr();
}
