#include "wav_sample_stream.h"

#include <stddef.h>

#include <Arduino.h>
#include <util/atomic.h>

#if ((WAV_SAMPLE_STREAM_BUFFER_BYTES & (WAV_SAMPLE_STREAM_BUFFER_BYTES - 1U)) != 0)
#error "WAV_SAMPLE_STREAM_BUFFER_BYTES must be a power of two"
#endif

#if (WAV_SAMPLE_STREAM_CAPACITY_SAMPLES > 32767U)
#error "Packed stream capacity must be <= 32767 samples"
#endif

volatile uint8_t wav_sample_stream_isr_bits[WAV_SAMPLE_STREAM_BUFFER_BYTES];
volatile uint16_t wav_sample_stream_isr_read_sequence = 0;
volatile uint16_t wav_sample_stream_isr_write_sequence = 0;
volatile uint8_t wav_sample_stream_isr_source_finished = 1;

static uint8_t wav_raw_buffer[WAV_SAMPLE_STREAM_REFILL_BLOCK];

static bool input_level = false;

static wav_sample_stream_config_t stream_config =
{
    100,
    155,
    false
};

static wav_reader_info_t stream_info;
static wav_reader_status_t stream_status = WAV_READER_STATUS_BAD_ARGUMENT;

static uint16_t wav_sample_stream_available_snapshot(void)
{
    uint16_t read_snapshot;
    uint16_t write_snapshot;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        read_snapshot = wav_sample_stream_isr_read_sequence;
        write_snapshot = wav_sample_stream_isr_write_sequence;
    }

    return (uint16_t)(write_snapshot - read_snapshot);
}

static uint8_t wav_sample_stream_decode(uint8_t sample)
{
    /*
        The center of the hysteresis window preserves the previous level.
        No undefined state and no artificial transition are introduced.
    */
    if (!input_level)
    {
        if (sample >= stream_config.high_threshold)
        {
            input_level = true;
        }
    }
    else
    {
        if (sample <= stream_config.low_threshold)
        {
            input_level = false;
        }
    }

    return (uint8_t)((input_level ^ stream_config.invert_signal) ? 1U : 0U);
}

static void wav_sample_stream_store_bit(uint16_t sequence, uint8_t level)
{
    uint16_t bit_position = (uint16_t)(sequence & WAV_SAMPLE_STREAM_BIT_MASK);
    uint16_t byte_index = (uint16_t)(bit_position >> 3);
    uint8_t bit_mask = (uint8_t)(1U << (bit_position & 7U));
    uint8_t previous = wav_sample_stream_isr_bits[byte_index];

    if (level)
    {
        wav_sample_stream_isr_bits[byte_index] =
            (uint8_t)(previous | bit_mask);
    }
    else
    {
        wav_sample_stream_isr_bits[byte_index] =
            (uint8_t)(previous & (uint8_t)~bit_mask);
    }
}

bool wav_sample_stream_open(const char *path,
                            const wav_sample_stream_config_t *config)
{
    if ((path == NULL) ||
        (config == NULL) ||
        (config->low_threshold >= config->high_threshold))
    {
        stream_status = WAV_READER_STATUS_BAD_ARGUMENT;
        return false;
    }

    wav_sample_stream_close();

    stream_config = *config;
    input_level = false;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        wav_sample_stream_isr_read_sequence = 0;
        wav_sample_stream_isr_write_sequence = 0;
        wav_sample_stream_isr_source_finished = 0;
    }

    if (!wav_reader_open(path, &stream_info))
    {
        stream_status = wav_reader_last_status();

        ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
        {
            wav_sample_stream_isr_source_finished = 1;
        }

        return false;
    }

    stream_status = WAV_READER_STATUS_OK;

    return wav_sample_stream_prefill();
}

void wav_sample_stream_close(void)
{
    wav_reader_close();

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        wav_sample_stream_isr_read_sequence = 0;
        wav_sample_stream_isr_write_sequence = 0;
        wav_sample_stream_isr_source_finished = 1;
    }

    input_level = false;
}

bool wav_sample_stream_refill_block(void)
{
    uint16_t read_snapshot;
    uint16_t write_snapshot;
    uint16_t used;
    uint16_t free_space;
    uint16_t request;
    uint16_t write_local;
    int16_t received;

    if (wav_sample_stream_isr_source_finished != 0U)
    {
        return true;
    }

    if (!wav_reader_is_open())
    {
        stream_status = wav_reader_last_status();
        return false;
    }

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        read_snapshot = wav_sample_stream_isr_read_sequence;
        write_snapshot = wav_sample_stream_isr_write_sequence;
    }

    used = (uint16_t)(write_snapshot - read_snapshot);

    if (used > WAV_SAMPLE_STREAM_CAPACITY_SAMPLES)
    {
        stream_status = WAV_READER_STATUS_IO_ERROR;
        return false;
    }

    free_space = (uint16_t)(WAV_SAMPLE_STREAM_CAPACITY_SAMPLES - used);

    if (free_space == 0U)
    {
        return true;
    }

    request = free_space;

    if (request > WAV_SAMPLE_STREAM_REFILL_BLOCK)
    {
        request = WAV_SAMPLE_STREAM_REFILL_BLOCK;
    }

    received = wav_reader_read_samples(wav_raw_buffer, request);

    if (received < 0)
    {
        stream_status = wav_reader_last_status();
        return false;
    }

    if (received == 0)
    {
        /*
            Publish source EOF only after all already prepared samples remain
            visible to the ISR. This byte store is atomic on ATmega2560.
        */
        wav_sample_stream_isr_source_finished = 1;
        return true;
    }

    write_local = write_snapshot;

    for (int16_t i = 0; i < received; i++)
    {
        wav_sample_stream_store_bit(
            write_local,
            wav_sample_stream_decode(wav_raw_buffer[i])
        );

        write_local = (uint16_t)(write_local + 1U);
    }

    /*
        Publish after all converted bits are visible in SRAM. The atomic
        region is just one 16-bit store; SD and conversion remain interruptible.
    */
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        asm volatile("" ::: "memory");
        wav_sample_stream_isr_write_sequence = write_local;
    }

    return true;
}

bool wav_sample_stream_prefill(void)
{
    while (wav_sample_stream_isr_source_finished == 0U)
    {
        uint16_t before = wav_sample_stream_available_snapshot();

        if (!wav_sample_stream_refill_block())
        {
            return false;
        }

        if (wav_sample_stream_available_snapshot() == before)
        {
            break;
        }
    }

    return true;
}

bool wav_sample_stream_pop(uint8_t *level)
{
    bool result;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        result = wav_sample_stream_pop_fast_from_isr(level);
    }

    return result;
}

uint16_t wav_sample_stream_available(void)
{
    return wav_sample_stream_available_snapshot();
}

bool wav_sample_stream_source_finished(void)
{
    return wav_sample_stream_isr_source_finished != 0U;
}

bool wav_sample_stream_finished(void)
{
    return (wav_sample_stream_isr_source_finished != 0U) &&
           (wav_sample_stream_available_snapshot() == 0U);
}

const wav_reader_info_t *wav_sample_stream_info(void)
{
    return wav_reader_is_open() ? &stream_info : NULL;
}

wav_reader_status_t wav_sample_stream_last_status(void)
{
    return stream_status;
}
