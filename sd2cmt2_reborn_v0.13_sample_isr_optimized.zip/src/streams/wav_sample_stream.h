#ifndef SD2CMT2_WAV_SAMPLE_STREAM_H
#define SD2CMT2_WAV_SAMPLE_STREAM_H

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>

#include "../formats/wav_reader.h"

/*
    Prepared binary samples, packed one bit per WAV sample.

    2048 SRAM bytes hold 16383 samples:
    - 742.8 ms at 22050 Hz
    - 371.5 ms at 44100 Hz
    - 341.3 ms at 48000 Hz

    Playback is sample-for-sample: one queued bit corresponds to exactly one
    source WAV sample period. There is no run-length conversion.
*/
#define WAV_SAMPLE_STREAM_BUFFER_BYTES 2048U
#define WAV_SAMPLE_STREAM_CAPACITY_SAMPLES \
    ((WAV_SAMPLE_STREAM_BUFFER_BYTES * 8U) - 1U)

#define WAV_SAMPLE_STREAM_REFILL_BLOCK 512U
#define WAV_SAMPLE_STREAM_BIT_MASK \
    ((WAV_SAMPLE_STREAM_BUFFER_BYTES * 8U) - 1U)

/*
    Low-level SPSC ABI used by the Timer1 driver.

    The driver knows only a prepared 1-bit FIFO; it does not know WAV parsing,
    SD, thresholding or hysteresis. These symbols are deliberately exposed to
    allow the critical ISR path to be inlined with no callback/function call.
*/
extern volatile uint8_t wav_sample_stream_isr_bits[WAV_SAMPLE_STREAM_BUFFER_BYTES];
extern volatile uint16_t wav_sample_stream_isr_read_sequence;
extern volatile uint16_t wav_sample_stream_isr_write_sequence;
extern volatile uint8_t wav_sample_stream_isr_source_finished;

static inline __attribute__((always_inline))
bool wav_sample_stream_pop_fast_from_isr(uint8_t *level)
{
    uint16_t read_local = wav_sample_stream_isr_read_sequence;
    uint16_t bit_position;
    uint8_t packed;

    if ((level == NULL) ||
        (read_local == wav_sample_stream_isr_write_sequence))
    {
        return false;
    }

    bit_position = (uint16_t)(read_local & WAV_SAMPLE_STREAM_BIT_MASK);
    packed = wav_sample_stream_isr_bits[bit_position >> 3];

    *level = (uint8_t)((packed >> (bit_position & 7U)) & 1U);

    wav_sample_stream_isr_read_sequence = (uint16_t)(read_local + 1U);
    return true;
}

static inline __attribute__((always_inline))
bool wav_sample_stream_finished_fast_from_isr(void)
{
    return (wav_sample_stream_isr_source_finished != 0U) &&
           (wav_sample_stream_isr_read_sequence ==
            wav_sample_stream_isr_write_sequence);
}

typedef struct
{
    uint8_t low_threshold;
    uint8_t high_threshold;
    bool invert_signal;

} wav_sample_stream_config_t;

bool wav_sample_stream_open(const char *path,
                            const wav_sample_stream_config_t *config);

void wav_sample_stream_close(void);

/*
    Foreground only. Reads up to WAV_SAMPLE_STREAM_REFILL_BLOCK WAV bytes,
    applies hysteresis, and publishes prepared 0/1 sample bits.
*/
bool wav_sample_stream_refill_block(void);

/* Fill all currently free storage before Timer1 starts. */
bool wav_sample_stream_prefill(void);

/* Foreground dequeue, used only by tests and diagnostics. */
bool wav_sample_stream_pop(uint8_t *level);

uint16_t wav_sample_stream_available(void);

bool wav_sample_stream_source_finished(void);

bool wav_sample_stream_finished(void);

const wav_reader_info_t *wav_sample_stream_info(void);

wav_reader_status_t wav_sample_stream_last_status(void);

#endif
