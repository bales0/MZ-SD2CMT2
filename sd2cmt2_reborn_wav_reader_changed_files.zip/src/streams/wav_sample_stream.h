#ifndef SD2CMT2_WAV_SAMPLE_STREAM_H
#define SD2CMT2_WAV_SAMPLE_STREAM_H

#include <stdbool.h>
#include <stdint.h>

#include "../formats/wav_reader.h"

/*
    Buffer contains already decoded logical READ levels (0 or 1).

    1024 samples:
    - 46.4 ms at 22050 Hz
    - 23.2 ms at 44100 Hz
    - 21.3 ms at 48000 Hz

    It must stay a power of two because indexing uses a mask.
*/
#define WAV_SAMPLE_STREAM_BUFFER_SIZE 1024U

typedef struct
{
    uint8_t low_threshold;
    uint8_t high_threshold;
    bool invert_signal;

} wav_sample_stream_config_t;

/*
    Opens the WAV file and fills the prepared-level ring buffer.
    Thresholding and hysteresis are done here, outside a future timer ISR.
*/
bool wav_sample_stream_open(const char *path,
                            const wav_sample_stream_config_t *config);

void wav_sample_stream_close(void);

/*
    Call from normal foreground code to replenish the buffer from SD.
    Never call from an ISR.
*/
bool wav_sample_stream_refill(void);

/* Safe for normal foreground code. */
bool wav_sample_stream_pop(uint8_t *level);

/*
    Intended for the future fixed-rate WAV timer ISR.
    It only dequeues a precomputed 0/1 value: no threshold, no SD access.
*/
bool wav_sample_stream_pop_from_isr(uint8_t *level);

uint16_t wav_sample_stream_available(void);

bool wav_sample_stream_source_finished(void);

bool wav_sample_stream_finished(void);

const wav_reader_info_t *wav_sample_stream_info(void);

wav_reader_status_t wav_sample_stream_last_status(void);

#endif
