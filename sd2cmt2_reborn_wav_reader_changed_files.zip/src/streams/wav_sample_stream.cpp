#include "wav_sample_stream.h"

#include <Arduino.h>
#include <util/atomic.h>

#if ((WAV_SAMPLE_STREAM_BUFFER_SIZE & (WAV_SAMPLE_STREAM_BUFFER_SIZE - 1U)) != 0)
#error "WAV_SAMPLE_STREAM_BUFFER_SIZE must be a power of two"
#endif

#if (WAV_SAMPLE_STREAM_BUFFER_SIZE > 32768U)
#error "WAV_SAMPLE_STREAM_BUFFER_SIZE must be <= 32768"
#endif

#define WAV_SAMPLE_STREAM_INDEX_MASK (WAV_SAMPLE_STREAM_BUFFER_SIZE - 1U)
#define WAV_SAMPLE_STREAM_CAPACITY   (WAV_SAMPLE_STREAM_BUFFER_SIZE - 1U)
#define WAV_SAMPLE_STREAM_READ_BLOCK 64U

static uint8_t wav_level_buffer[WAV_SAMPLE_STREAM_BUFFER_SIZE];
static uint8_t wav_raw_buffer[WAV_SAMPLE_STREAM_READ_BLOCK];

/*
    Monotonic sequence counters are safer than a shared 16-bit count:
    producer writes write_sequence only after the prepared bytes are present;
    the future ISR only writes read_sequence after it has consumed a byte.
*/
static volatile uint16_t read_sequence = 0;
static volatile uint16_t write_sequence = 0;

static bool input_level = false;
static bool source_finished = false;

static wav_sample_stream_config_t stream_config =
{
    100,
    155,
    false
};

static wav_reader_info_t stream_info;
static wav_reader_status_t stream_status = WAV_READER_STATUS_BAD_ARGUMENT;

static uint16_t wav_sample_stream_available_snapshot(void)
{
    uint16_t read_snapshot;
    uint16_t write_snapshot;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        read_snapshot = read_sequence;
        write_snapshot = write_sequence;
    }

    return (uint16_t)(write_snapshot - read_snapshot);
}

static uint8_t wav_sample_stream_decode(uint8_t sample)
{
    /*
        The middle of the hysteresis window is defined: preserve the previous
        logical state. Therefore samples near the center never create an
        undefined state or an artificial edge.
    */
    if (!input_level)
    {
        if (sample >= stream_config.high_threshold)
        {
            input_level = true;
        }
    }
    else
    {
        if (sample <= stream_config.low_threshold)
        {
            input_level = false;
        }
    }

    return (uint8_t)((input_level ^ stream_config.invert_signal) ? 1U : 0U);
}

static bool wav_sample_stream_pop_internal(uint8_t *level)
{
    uint16_t read_local;

    if (level == NULL)
    {
        return false;
    }

    read_local = read_sequence;

    if (read_local == write_sequence)
    {
        return false;
    }

    *level = wav_level_buffer[read_local & WAV_SAMPLE_STREAM_INDEX_MASK];

    /*
        This assignment is one 16-bit write. In foreground code it is wrapped
        in ATOMIC_BLOCK; in an ISR interrupts are already disabled.
    */
    read_sequence = (uint16_t)(read_local + 1U);

    return true;
}

bool wav_sample_stream_open(const char *path,
                            const wav_sample_stream_config_t *config)
{
    if ((path == NULL) ||
        (config == NULL) ||
        (config->low_threshold >= config->high_threshold))
    {
        stream_status = WAV_READER_STATUS_BAD_ARGUMENT;
        return false;
    }

    wav_sample_stream_close();

    stream_config = *config;
    input_level = false;
    source_finished = false;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        read_sequence = 0;
        write_sequence = 0;
    }

    if (!wav_reader_open(path, &stream_info))
    {
        stream_status = wav_reader_last_status();
        return false;
    }

    stream_status = WAV_READER_STATUS_OK;

    return wav_sample_stream_refill();
}

void wav_sample_stream_close(void)
{
    wav_reader_close();

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        read_sequence = 0;
        write_sequence = 0;
    }

    input_level = false;
    source_finished = true;
}

bool wav_sample_stream_refill(void)
{
    while (!source_finished)
    {
        uint16_t read_snapshot;
        uint16_t write_snapshot;
        uint16_t used;
        uint16_t free_space;
        uint16_t request;
        uint16_t write_local;
        int16_t received;

        ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
        {
            read_snapshot = read_sequence;
            write_snapshot = write_sequence;
        }

        used = (uint16_t)(write_snapshot - read_snapshot);

        if (used > WAV_SAMPLE_STREAM_CAPACITY)
        {
            /*
                This should never happen. It means the ring ownership rules
                were violated, so stop rather than overwrite unread samples.
            */
            stream_status = WAV_READER_STATUS_IO_ERROR;
            return false;
        }

        free_space = (uint16_t)(WAV_SAMPLE_STREAM_CAPACITY - used);

        if (free_space == 0)
        {
            break;
        }

        request = free_space;

        if (request > WAV_SAMPLE_STREAM_READ_BLOCK)
        {
            request = WAV_SAMPLE_STREAM_READ_BLOCK;
        }

        received = wav_reader_read_samples(wav_raw_buffer, request);

        if (received < 0)
        {
            stream_status = wav_reader_last_status();
            return false;
        }

        if (received == 0)
        {
            source_finished = true;
            break;
        }

        write_local = write_snapshot;

        for (int16_t i = 0; i < received; i++)
        {
            wav_level_buffer[write_local & WAV_SAMPLE_STREAM_INDEX_MASK] =
                wav_sample_stream_decode(wav_raw_buffer[i]);

            write_local = (uint16_t)(write_local + 1U);
        }

        /*
            Publish all converted samples atomically after their RAM writes are
            complete. A future ISR can only see fully prepared items.
        */
        ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
        {
            write_sequence = write_local;
        }
    }

    return true;
}

bool wav_sample_stream_pop(uint8_t *level)
{
    bool result;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        result = wav_sample_stream_pop_internal(level);
    }

    return result;
}

bool wav_sample_stream_pop_from_isr(uint8_t *level)
{
    return wav_sample_stream_pop_internal(level);
}

uint16_t wav_sample_stream_available(void)
{
    return wav_sample_stream_available_snapshot();
}

bool wav_sample_stream_source_finished(void)
{
    return source_finished;
}

bool wav_sample_stream_finished(void)
{
    return source_finished && (wav_sample_stream_available_snapshot() == 0);
}

const wav_reader_info_t *wav_sample_stream_info(void)
{
    return wav_reader_is_open() ? &stream_info : NULL;
}

wav_reader_status_t wav_sample_stream_last_status(void)
{
    return stream_status;
}
