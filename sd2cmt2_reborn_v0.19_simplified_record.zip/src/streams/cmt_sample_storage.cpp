#include "cmt_sample_storage.h"

cmt_sample_shared_storage_t cmt_sample_shared_storage;
