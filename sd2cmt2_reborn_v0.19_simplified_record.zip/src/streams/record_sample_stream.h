#ifndef SD2CMT2_RECORD_SAMPLE_STREAM_H
#define SD2CMT2_RECORD_SAMPLE_STREAM_H

#include <stdbool.h>
#include <stdint.h>

#include "cmt_sample_storage.h"

/*
    One byte stores eight chronological WRITE samples, bit0 first.

    2047 usable bytes store 16,376 samples:
    - 742.7 ms at 22,050 Hz
    - 371.3 ms at 44,100 Hz

    The storage aliases the WAV playback FIFO. PLAY and RECORD cannot run
    together, so this costs no additional 2 KiB SRAM.
*/
#define RECORD_SAMPLE_STREAM_BUFFER_BYTES CMT_SAMPLE_SHARED_BUFFER_BYTES
#define RECORD_SAMPLE_STREAM_CAPACITY_BYTES \
    (RECORD_SAMPLE_STREAM_BUFFER_BYTES - 1U)
#define RECORD_SAMPLE_STREAM_BYTE_MASK \
    (RECORD_SAMPLE_STREAM_BUFFER_BYTES - 1U)

#define record_sample_stream_bytes \
    ((volatile uint8_t *)cmt_sample_shared_storage.record.fifo)

void record_sample_stream_reset(void);

/* Producer: Timer1 ISR. Returns false only when the ring is full. */
bool record_sample_stream_push_byte_from_isr(uint8_t packed_byte);

/*
    Consumer: foreground only. Copies up to max_bytes without disabling the
    sample timer during the byte copy.
*/
uint16_t record_sample_stream_pop_bytes(uint8_t *destination,
                                        uint16_t max_bytes);

uint16_t record_sample_stream_available_bytes(void);

uint8_t record_sample_stream_fill_percent(void);

#endif
