#ifndef SD2CMT2_CMT_SAMPLE_STORAGE_H
#define SD2CMT2_CMT_SAMPLE_STORAGE_H

#include <stdint.h>

/*
    PLAY and RECORD are mutually exclusive. They therefore share:
    - 2048 B packed realtime FIFO
    -  512 B foreground work block

    Before v0.19, playback raw input, record raw output and record PCM output
    were three separate 512 B arrays. This union removes 1024 B of permanent
    SRAM while retaining the same realtime FIFO capacity.
*/
#define CMT_SAMPLE_SHARED_BUFFER_BYTES 2048U
#define CMT_SAMPLE_SHARED_WORK_BYTES    512U

typedef union
{
    struct
    {
        uint8_t fifo[CMT_SAMPLE_SHARED_BUFFER_BYTES];
        uint8_t work[CMT_SAMPLE_SHARED_WORK_BYTES];
    } playback;

    struct
    {
        uint8_t fifo[CMT_SAMPLE_SHARED_BUFFER_BYTES];
        uint8_t work[CMT_SAMPLE_SHARED_WORK_BYTES];
    } record;

} cmt_sample_shared_storage_t;

extern cmt_sample_shared_storage_t cmt_sample_shared_storage;

#endif
