#include "wav_record_engine.h"

#include <stdio.h>
#include <string.h>

#include "../drivers/sdcard.h"
#include "../drivers/wav_record_driver.h"
#include "../streams/cmt_sample_storage.h"
#include "../streams/record_sample_stream.h"

#define WAV_RECORD_PATH_MAX 160U
#define WAV_RECORD_FILENAME_MAX 16U

/* Raw capture is one packed bit per input sample. */
#define WAV_RECORD_RAW_WRITE_BLOCK_BYTES 512U
#define WAV_RECORD_CONVERT_RAW_BLOCK_BYTES 64U

/* RIFF + fmt + JUNK + data header, padded to one sector. */
#define WAV_RECORD_HEADER_BYTES 512U
#define WAV_RECORD_JUNK_PAYLOAD_BYTES 460U

/* Optional raw capacity reservation: 1 MiB raw = about 190 s at 44.1 kHz. */
#define WAV_RECORD_RAW_PREALLOCATE_BYTES (1024UL * 1024UL)

static wav_record_engine_state_t record_state = WAV_RECORD_ENGINE_STOPPED;

static char record_full_path[WAV_RECORD_PATH_MAX];
static char record_filename[WAV_RECORD_FILENAME_MAX];
static char record_error_text[17];

static uint32_t record_sample_rate = 0UL;
static uint32_t raw_bytes_written = 0UL;
static uint32_t final_data_bytes = 0UL;
static uint32_t final_file_bytes = 0UL;
static uint32_t pcm_bytes_written = 0UL;
static uint32_t conversion_raw_remaining = 0UL;

static bool raw_capture_closed = false;
static bool final_tail_taken = false;
static bool tail_converted = false;
static uint8_t final_tail_byte = 0U;
static uint8_t final_tail_bits = 0U;

#define wav_record_work_block (cmt_sample_shared_storage.record.work)

static void wav_record_set_error(const char *text)
{
    if (text == NULL)
    {
        record_error_text[0] = '\0';
        return;
    }

    strncpy(record_error_text, text, sizeof(record_error_text) - 1U);
    record_error_text[sizeof(record_error_text) - 1U] = '\0';
}

static void wav_record_put_le16(uint8_t *target, uint16_t value)
{
    target[0] = (uint8_t)(value & 0xFFU);
    target[1] = (uint8_t)((value >> 8) & 0xFFU);
}

static void wav_record_put_le32(uint8_t *target, uint32_t value)
{
    target[0] = (uint8_t)(value & 0xFFUL);
    target[1] = (uint8_t)((value >> 8) & 0xFFUL);
    target[2] = (uint8_t)((value >> 16) & 0xFFUL);
    target[3] = (uint8_t)((value >> 24) & 0xFFUL);
}

static bool wav_record_add_u32(uint32_t left, uint32_t right,
                               uint32_t *result)
{
    if ((result == NULL) || (left > (0xFFFFFFFFUL - right)))
    {
        return false;
    }

    *result = left + right;
    return true;
}

static bool wav_record_make_paths(const char *directory_path)
{
    if ((directory_path == NULL) || (directory_path[0] == '\0'))
    {
        wav_record_set_error("BAD DIRECTORY");
        return false;
    }

    for (uint16_t index = 1U; index <= 9999U; index++)
    {
        int length;

        if (strcmp(directory_path, "/") == 0)
        {
            length = snprintf(record_full_path, sizeof(record_full_path),
                              "/REC%04u.WAV", (unsigned int)index);
        }
        else
        {
            length = snprintf(record_full_path, sizeof(record_full_path),
                              "%s/REC%04u.WAV", directory_path,
                              (unsigned int)index);
        }

        if ((length <= 0) || ((size_t)length >= sizeof(record_full_path)))
        {
            wav_record_set_error("PATH TOO LONG");
            return false;
        }

        if (!sdcard_file_exists(record_full_path))
        {
            snprintf(record_filename, sizeof(record_filename),
                     "REC%04u.WAV", (unsigned int)index);
            return true;
        }
    }

    wav_record_set_error("REC NAMES FULL");
    return false;
}

static void wav_record_fail_and_close(const char *text)
{
    if ((text != NULL) && (text != record_error_text))
    {
        wav_record_set_error(text);
    }

    wav_record_driver_stop();
    sdcard_file_close();
    record_state = WAV_RECORD_ENGINE_ERROR;
}

static bool wav_record_write_placeholder_header(void)
{
    memset(wav_record_work_block, 0, WAV_RECORD_HEADER_BYTES);

    if (sdcard_file_write(wav_record_work_block, WAV_RECORD_HEADER_BYTES) !=
        (int16_t)WAV_RECORD_HEADER_BYTES)
    {
        wav_record_set_error("HEADER CREATE");
        return false;
    }

    /* Commit metadata/cache before the realtime timer is allowed to start. */
    if (!sdcard_file_sync())
    {
        wav_record_set_error("HEADER SYNC");
        return false;
    }

    return true;
}

static bool wav_record_drain_raw(bool allow_partial)
{
    uint16_t available = record_sample_stream_available_bytes();
    uint16_t request;
    uint16_t received;

    if (available == 0U)
    {
        return true;
    }

    if (!allow_partial && (available < WAV_RECORD_RAW_WRITE_BLOCK_BYTES))
    {
        return true;
    }

    request = allow_partial ? available : WAV_RECORD_RAW_WRITE_BLOCK_BYTES;

    if (request > WAV_RECORD_RAW_WRITE_BLOCK_BYTES)
    {
        request = WAV_RECORD_RAW_WRITE_BLOCK_BYTES;
    }

    received = record_sample_stream_pop_bytes(wav_record_work_block, request);

    if (received == 0U)
    {
        return true;
    }

    if (!allow_partial && (received != WAV_RECORD_RAW_WRITE_BLOCK_BYTES))
    {
        wav_record_set_error("REC FIFO RACE");
        return false;
    }

    if (sdcard_file_write(wav_record_work_block, received) !=
        (int16_t)received)
    {
        wav_record_set_error("RAW WRITE ERR");
        return false;
    }

    raw_bytes_written += (uint32_t)received;
    return true;
}

static bool wav_record_drain_full_sectors(void)
{
    while (record_sample_stream_available_bytes() >=
           WAV_RECORD_RAW_WRITE_BLOCK_BYTES)
    {
        if (!wav_record_drain_raw(false))
        {
            return false;
        }
    }

    return true;
}

static bool wav_record_drain_all_raw(void)
{
    while (record_sample_stream_available_bytes() != 0U)
    {
        if (!wav_record_drain_raw(true))
        {
            return false;
        }
    }

    return true;
}

static bool wav_record_take_tail_once(void)
{
    if (final_tail_taken)
    {
        return true;
    }

    final_tail_taken = true;
    final_tail_byte = 0U;
    final_tail_bits = 0U;

    /* A zero-length partial tail is normal at an 8-sample boundary. */
    (void)wav_record_driver_take_tail(&final_tail_byte, &final_tail_bits);
    return true;
}

static bool wav_record_finish_raw_capture(void)
{
    uint32_t raw_samples;

    if (raw_capture_closed)
    {
        return true;
    }

    if (!wav_record_drain_all_raw())
    {
        return false;
    }

    if (!wav_record_take_tail_once())
    {
        wav_record_set_error("TAIL ERROR");
        return false;
    }

    raw_samples = raw_bytes_written * 8UL;

    if (!wav_record_add_u32(raw_samples, (uint32_t)final_tail_bits,
                            &final_data_bytes) ||
        !wav_record_add_u32(WAV_RECORD_HEADER_BYTES, final_data_bytes,
                            &final_file_bytes))
    {
        wav_record_set_error("FILE TOO BIG");
        return false;
    }

    /* RIFF chunks are word aligned; the data length itself remains unpadded. */
    if ((final_data_bytes & 1UL) != 0UL)
    {
        if (!wav_record_add_u32(final_file_bytes, 1UL, &final_file_bytes))
        {
            wav_record_set_error("FILE TOO BIG");
            return false;
        }
    }

    if (!sdcard_file_sync())
    {
        wav_record_set_error("RAW SYNC ERR");
        return false;
    }

    raw_capture_closed = true;
    conversion_raw_remaining = raw_bytes_written;
    pcm_bytes_written = 0UL;
    tail_converted = (final_tail_bits == 0U);
    return true;
}

/*
    Ensure the final expanded data range exists. This runs after the sample
    timer stopped, so allocation latency is harmless. If preallocation already
    covers the range, no media allocation occurs here.
*/
static bool wav_record_ensure_final_length(void)
{
    uint32_t current_length = sdcard_file_size();

    if (current_length >= final_file_bytes)
    {
        return true;
    }

    if (!sdcard_file_seek(final_file_bytes - 1UL))
    {
        wav_record_set_error("FINAL SEEK ERR");
        return false;
    }

    wav_record_work_block[0] = 0U;

    if (sdcard_file_write(wav_record_work_block, 1U) != 1)
    {
        wav_record_set_error("FINAL EXTEND");
        return false;
    }

    return true;
}

/*
    Convert the partial final byte first. Its PCM destination is beyond every
    packed raw byte, so it cannot overwrite unconverted input.
*/
static bool wav_record_convert_tail(void)
{
    uint32_t output_offset;

    if (tail_converted)
    {
        return true;
    }

    for (uint8_t bit = 0U; bit < final_tail_bits; bit++)
    {
        wav_record_work_block[bit] =
            (final_tail_byte & (uint8_t)(1U << bit)) ? 235U : 20U;
    }

    output_offset = WAV_RECORD_HEADER_BYTES + (raw_bytes_written * 8UL);

    if (!sdcard_file_seek(output_offset) ||
        (sdcard_file_write(wav_record_work_block, final_tail_bits) !=
         (int16_t)final_tail_bits))
    {
        wav_record_set_error("TAIL WRITE ERR");
        return false;
    }

    pcm_bytes_written += (uint32_t)final_tail_bits;
    tail_converted = true;
    return true;
}

/*
    One 64-byte packed block becomes one 512-byte PCM block in the same 512 B
    work area. Reading and expanding backwards keeps each input byte alive
    until it has been consumed, and the file conversion is also backwards so
    already-written PCM can never overwrite unread raw capture data.
*/
static bool wav_record_convert_one_raw_block(void)
{
    uint16_t raw_count;
    uint32_t raw_start;
    uint32_t source_offset;
    uint32_t output_offset;

    if (conversion_raw_remaining == 0UL)
    {
        return true;
    }

    raw_count = (conversion_raw_remaining >=
                 WAV_RECORD_CONVERT_RAW_BLOCK_BYTES) ?
                WAV_RECORD_CONVERT_RAW_BLOCK_BYTES :
                (uint16_t)conversion_raw_remaining;

    raw_start = conversion_raw_remaining - (uint32_t)raw_count;
    source_offset = WAV_RECORD_HEADER_BYTES + raw_start;

    if (!sdcard_file_seek(source_offset) ||
        (sdcard_file_read(wav_record_work_block, raw_count) !=
         (int16_t)raw_count))
    {
        wav_record_set_error("RAW READ ERR");
        return false;
    }

    for (uint16_t byte_index = raw_count; byte_index != 0U; byte_index--)
    {
        uint16_t input_index = (uint16_t)(byte_index - 1U);
        uint8_t packed = wav_record_work_block[input_index];
        uint16_t output_base = (uint16_t)(input_index * 8U);

        for (uint8_t bit_index = 8U; bit_index != 0U; bit_index--)
        {
            uint8_t bit = (uint8_t)(bit_index - 1U);
            wav_record_work_block[output_base + bit] =
                (packed & (uint8_t)(1U << bit)) ? 235U : 20U;
        }
    }

    output_offset = WAV_RECORD_HEADER_BYTES + (raw_start * 8UL);

    if (!sdcard_file_seek(output_offset) ||
        (sdcard_file_write(wav_record_work_block,
                           (uint16_t)(raw_count * 8U)) !=
         (int16_t)(raw_count * 8U)))
    {
        wav_record_set_error("WAV WRITE ERR");
        return false;
    }

    pcm_bytes_written += (uint32_t)raw_count * 8UL;
    conversion_raw_remaining = raw_start;
    return true;
}

static bool wav_record_write_final_header(void)
{
    uint32_t riff_size;

    if (final_file_bytes < 8UL)
    {
        wav_record_set_error("BAD WAV SIZE");
        return false;
    }

    riff_size = final_file_bytes - 8UL;

    memset(wav_record_work_block, 0, WAV_RECORD_HEADER_BYTES);
    memcpy(wav_record_work_block + 0U, "RIFF", 4U);
    wav_record_put_le32(wav_record_work_block + 4U, riff_size);
    memcpy(wav_record_work_block + 8U, "WAVE", 4U);

    memcpy(wav_record_work_block + 12U, "fmt ", 4U);
    wav_record_put_le32(wav_record_work_block + 16U, 16UL);
    wav_record_put_le16(wav_record_work_block + 20U, 1U);
    wav_record_put_le16(wav_record_work_block + 22U, 1U);
    wav_record_put_le32(wav_record_work_block + 24U, record_sample_rate);
    wav_record_put_le32(wav_record_work_block + 28U, record_sample_rate);
    wav_record_put_le16(wav_record_work_block + 32U, 1U);
    wav_record_put_le16(wav_record_work_block + 34U, 8U);

    memcpy(wav_record_work_block + 36U, "JUNK", 4U);
    wav_record_put_le32(wav_record_work_block + 40U,
                        WAV_RECORD_JUNK_PAYLOAD_BYTES);
    memcpy(wav_record_work_block + 504U, "data", 4U);
    wav_record_put_le32(wav_record_work_block + 508U, final_data_bytes);

    if (!sdcard_file_seek(0UL) ||
        (sdcard_file_write(wav_record_work_block, WAV_RECORD_HEADER_BYTES) !=
         (int16_t)WAV_RECORD_HEADER_BYTES))
    {
        wav_record_set_error("WAV HEADER ERR");
        return false;
    }

    return true;
}

static bool wav_record_complete_conversion(void)
{
    /* The last odd data byte must be followed by one zero padding byte. */
    if ((final_data_bytes & 1UL) != 0UL)
    {
        wav_record_work_block[0] = 0U;

        if (!sdcard_file_seek(WAV_RECORD_HEADER_BYTES + final_data_bytes) ||
            (sdcard_file_write(wav_record_work_block, 1U) != 1))
        {
            wav_record_set_error("WAV PAD ERR");
            return false;
        }
    }

    if (!wav_record_write_final_header())
    {
        return false;
    }

    if (!sdcard_file_truncate(final_file_bytes) || !sdcard_file_sync())
    {
        wav_record_set_error("WAV CLOSE ERR");
        return false;
    }

    sdcard_file_close();
    record_state = WAV_RECORD_ENGINE_FINISHED;
    return true;
}

void wav_record_engine_init(void)
{
    wav_record_driver_init();

    record_state = WAV_RECORD_ENGINE_STOPPED;
    record_full_path[0] = '\0';
    record_filename[0] = '\0';
    record_error_text[0] = '\0';
    record_sample_rate = 0UL;
    raw_bytes_written = 0UL;
    final_data_bytes = 0UL;
    final_file_bytes = 0UL;
    pcm_bytes_written = 0UL;
    conversion_raw_remaining = 0UL;
    raw_capture_closed = false;
    final_tail_taken = false;
    tail_converted = false;
    final_tail_byte = 0U;
    final_tail_bits = 0U;
}

bool wav_record_engine_start(const char *directory_path,
                             uint32_t sample_rate)
{
    wav_record_engine_init();

    if (!sdcard_is_mounted())
    {
        wav_record_set_error("SD CARD ERROR");
        record_state = WAV_RECORD_ENGINE_ERROR;
        return false;
    }

    if (!wav_record_driver_prepare(sample_rate))
    {
        wav_record_set_error("BAD REC RATE");
        record_state = WAV_RECORD_ENGINE_ERROR;
        return false;
    }

    record_sample_rate = sample_rate;

    if (!wav_record_make_paths(directory_path))
    {
        record_state = WAV_RECORD_ENGINE_ERROR;
        return false;
    }

    if (!sdcard_file_open_write(record_full_path))
    {
        wav_record_set_error("WAV CREATE ERR");
        record_state = WAV_RECORD_ENGINE_ERROR;
        return false;
    }

    /* Optional reservation happens before Timer1 starts. */
    (void)sdcard_file_preallocate(WAV_RECORD_RAW_PREALLOCATE_BYTES);

    if (!sdcard_file_seek(0UL) || !wav_record_write_placeholder_header())
    {
        wav_record_fail_and_close(record_error_text);
        return false;
    }

    if (!wav_record_driver_start())
    {
        wav_record_fail_and_close("REC TIMER ERR");
        return false;
    }

    record_state = WAV_RECORD_ENGINE_RECORDING;
    return true;
}

void wav_record_engine_request_stop(void)
{
    if (record_state != WAV_RECORD_ENGINE_RECORDING)
    {
        return;
    }

    wav_record_driver_stop();
    record_state = WAV_RECORD_ENGINE_FINALIZING;
}

void wav_record_engine_service(void)
{
    wav_record_driver_state_t driver_state;

    if (record_state == WAV_RECORD_ENGINE_RECORDING)
    {
        driver_state = wav_record_driver_get_state();

        if (driver_state == WAV_RECORD_DRIVER_OVERRUN)
        {
            wav_record_fail_and_close("REC OVERFLOW");
            return;
        }

        if (!wav_record_drain_full_sectors())
        {
            wav_record_fail_and_close(record_error_text);
        }

        return;
    }

    if (record_state != WAV_RECORD_ENGINE_FINALIZING)
    {
        return;
    }

    if (!raw_capture_closed)
    {
        if (!wav_record_finish_raw_capture())
        {
            wav_record_fail_and_close(record_error_text);
        }
        return;
    }

    if (!wav_record_ensure_final_length())
    {
        wav_record_fail_and_close(record_error_text);
        return;
    }

    if (!wav_record_convert_tail())
    {
        wav_record_fail_and_close(record_error_text);
        return;
    }

    if (conversion_raw_remaining != 0UL)
    {
        if (!wav_record_convert_one_raw_block())
        {
            wav_record_fail_and_close(record_error_text);
        }
        return;
    }

    if (pcm_bytes_written != final_data_bytes)
    {
        wav_record_fail_and_close("CONVERT SIZE");
        return;
    }

    if (!wav_record_complete_conversion())
    {
        wav_record_fail_and_close(record_error_text);
    }
}

wav_record_engine_state_t wav_record_engine_get_state(void)
{
    return record_state;
}

const char *wav_record_engine_get_filename(void)
{
    return record_filename;
}

const char *wav_record_engine_get_full_path(void)
{
    return record_full_path;
}

const char *wav_record_engine_get_error_text(void)
{
    return record_error_text;
}

uint32_t wav_record_engine_get_sample_rate(void)
{
    return record_sample_rate;
}

uint32_t wav_record_engine_get_captured_samples(void)
{
    if (record_state != WAV_RECORD_ENGINE_RECORDING)
    {
        return final_data_bytes;
    }

    return (raw_bytes_written * 8UL) +
           ((uint32_t)record_sample_stream_available_bytes() * 8UL) +
           (uint32_t)wav_record_driver_get_pending_sample_count();
}

uint8_t wav_record_engine_get_buffer_fill_percent(void)
{
    return record_sample_stream_fill_percent();
}

uint8_t wav_record_engine_get_buffer_headroom_percent(void)
{
    uint8_t fill = record_sample_stream_fill_percent();
    return (fill >= 100U) ? 0U : (uint8_t)(100U - fill);
}

uint8_t wav_record_engine_get_write_pin(void)
{
    return wav_record_driver_get_write_pin();
}
