#ifndef SD2CMT2_SDCARD_H
#define SD2CMT2_SDCARD_H

#include <stdbool.h>
#include <stdint.h>

typedef struct
{
    char name[32];
    bool is_dir;
    uint32_t size;

} sdcard_entry_t;

void sdcard_early_prepare_pins(void);

bool sdcard_init(void);

bool sdcard_is_mounted(void);

uint16_t sdcard_count_entries(const char *path, uint16_t max_entries);

bool sdcard_read_entry_by_index(const char *path, uint16_t index, sdcard_entry_t *entry);

uint16_t sdcard_count_root_entries(uint16_t max_entries);

bool sdcard_read_root_entry_by_index(uint16_t index, sdcard_entry_t *entry);

/*
    Sequential one-file stream for format readers and in-place recording conversion.
    All functions are foreground only; never use them from a timer ISR.
*/
bool sdcard_file_open_read(const char *path);
bool sdcard_file_open_write(const char *path);
bool sdcard_file_exists(const char *path);

int16_t sdcard_file_read(void *buffer, uint16_t size);
int16_t sdcard_file_write(const void *buffer, uint16_t size);

/*
    Reserve contiguous clusters before recording starts. The reservation is
    optional; callers may continue if it fails due to a nearly full card.
*/
bool sdcard_file_preallocate(uint32_t length);
bool sdcard_file_truncate(uint32_t length);
bool sdcard_file_sync(void);

bool sdcard_file_seek(uint32_t position);
uint32_t sdcard_file_size(void);
uint32_t sdcard_file_position(void);
bool sdcard_file_is_open(void);
void sdcard_file_close(void);

/* Remove a closed file. Used only after successful raw->WAV conversion. */
bool sdcard_file_remove(const char *path);

const char *sdcard_last_error(void);
uint8_t sdcard_last_error_code(void);
uint8_t sdcard_last_error_data(void);

#endif
