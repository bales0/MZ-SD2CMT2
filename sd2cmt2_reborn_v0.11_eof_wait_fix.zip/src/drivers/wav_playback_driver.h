#ifndef SD2CMT2_WAV_PLAYBACK_DRIVER_H
#define SD2CMT2_WAV_PLAYBACK_DRIVER_H

#include <stdbool.h>
#include <stdint.h>

/*
    CMT READ physical output. The verified current Reborn mapping in mzio.cpp
    is Mega D2. Override only if a future board revision changes wiring:
        build_flags = -DCMT_READ_PIN=<mega_pin>
*/
#ifndef CMT_READ_PIN
#define CMT_READ_PIN 2
#endif

#ifndef WAV_PLAYBACK_READ_PIN
#define WAV_PLAYBACK_READ_PIN CMT_READ_PIN
#endif

/*
    Pop one prepared output run:
      samples = count of WAV sample periods for which level remains valid.
      level   = logical READ level, already thresholded/inverted.
*/
typedef bool (*wav_playback_pop_run_fn)(uint16_t *samples, uint8_t *level);
typedef bool (*wav_playback_source_finished_fn)(void);

typedef enum
{
    WAV_PLAYBACK_DRIVER_STOPPED = 0,
    WAV_PLAYBACK_DRIVER_READY,
    WAV_PLAYBACK_DRIVER_RUNNING,
    WAV_PLAYBACK_DRIVER_PAUSED,

    /*
        The current run ended but the foreground producer has not yet supplied
        the next run and has not yet confirmed EOF. Timer5 is stopped here;
        this is recoverable and is not an error state.
    */
    WAV_PLAYBACK_DRIVER_WAITING_DATA,

    WAV_PLAYBACK_DRIVER_FINISHED,
    WAV_PLAYBACK_DRIVER_UNDERRUN,
    WAV_PLAYBACK_DRIVER_BAD_RATE,
    WAV_PLAYBACK_DRIVER_BAD_ARGUMENT
} wav_playback_driver_state_t;

void wav_playback_driver_init(void);

bool wav_playback_driver_prepare(uint32_t sample_rate,
                                 wav_playback_pop_run_fn pop_run,
                                 wav_playback_source_finished_fn source_finished);

bool wav_playback_driver_start(void);
bool wav_playback_driver_pause(void);
bool wav_playback_driver_resume(void);

/*
    Restart Timer5 after WAV foreground code supplied one or more runs while
    the driver was in WAV_PLAYBACK_DRIVER_WAITING_DATA.
*/
bool wav_playback_driver_continue_after_wait(void);

void wav_playback_driver_stop(void);

wav_playback_driver_state_t wav_playback_driver_get_state(void);
uint32_t wav_playback_driver_get_sample_rate(void);
uint8_t wav_playback_driver_get_read_pin(void);

/*
    Counts logical output transitions. Shown on LCD during PLY as a direct
    diagnostic: a 1 kHz square WAV should advance by about 2000 per second.
*/
uint16_t wav_playback_driver_get_edge_count(void);

#endif
