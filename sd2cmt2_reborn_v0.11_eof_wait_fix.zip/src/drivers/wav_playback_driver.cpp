#include "wav_playback_driver.h"

#include <stddef.h>

#include <Arduino.h>
#include <avr/interrupt.h>
#include <util/atomic.h>

#if !defined(TIMER5_COMPA_vect)
#error "WAV playback driver requires Timer5 (Arduino Mega 2560 target)"
#endif

/*
    Timer5 uses CTC mode. Unlike v0.09 it is not scheduled per WAV sample.
    It wakes only when a prepared constant-level run ends, with long runs
    split into <= 65535 CPU-clock timer segments.
*/
static volatile uint8_t driver_state = WAV_PLAYBACK_DRIVER_STOPPED;

static wav_playback_pop_run_fn pop_run_callback = NULL;
static wav_playback_source_finished_fn source_finished_callback = NULL;

static volatile uint32_t timer_rate = 0;
static volatile uint32_t timer_phase = 0;
static volatile uint16_t max_segment_samples = 0;

static volatile uint16_t active_run_remaining = 0;
static volatile uint16_t scheduled_segment_samples = 0;
static volatile uint32_t phase_before_segment = 0;
static volatile bool active_run_valid = false;

static volatile uint8_t current_output_level = 0;
static volatile uint16_t output_edge_count = 0;

static volatile uint8_t *read_output_port = NULL;
static uint8_t read_output_mask = 0;

static inline void wav_playback_set_level(uint8_t level)
{
    uint8_t normalized_level = (uint8_t)(level & 1U);
    uint8_t port_value = *read_output_port;
    uint8_t level_mask = (uint8_t)(0U - normalized_level);

    level_mask &= read_output_mask;

    *read_output_port = (uint8_t)(
        (port_value & (uint8_t)~read_output_mask) | level_mask
    );

    if (normalized_level != current_output_level)
    {
        current_output_level = normalized_level;
        output_edge_count++;
    }
}

static inline void wav_playback_disable_timer_from_isr(void)
{
    TCCR5B = _BV(WGM52);
    TIMSK5 &= (uint8_t)~_BV(OCIE5A);
    TIFR5 = _BV(OCF5A);
    scheduled_segment_samples = 0;
}

static wav_playback_driver_state_t wav_playback_state_snapshot(void)
{
    uint8_t state;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        state = driver_state;
    }

    return (wav_playback_driver_state_t)state;
}

static bool wav_playback_load_next_run(bool from_isr)
{
    uint16_t samples = 0;
    uint8_t level = 0;
    bool result;

    if (from_isr)
    {
        result = pop_run_callback(&samples, &level);
    }
    else
    {
        result = pop_run_callback(&samples, &level);
    }

    if (!result || (samples == 0))
    {
        return false;
    }

    active_run_remaining = samples;
    active_run_valid = true;
    wav_playback_set_level(level);
    return true;
}

/*
    Schedules the next portion of the active run. The integer timer count is
    derived from N sample periods in one operation. phase carries the remainder
    so total time remains exact over the complete WAV.
*/
static inline bool wav_playback_schedule_active_run_segment(void)
{
    uint16_t segment_samples;
    uint32_t numerator;
    uint32_t ticks;

    if (!active_run_valid || (active_run_remaining == 0) ||
        (max_segment_samples == 0))
    {
        return false;
    }

    segment_samples = active_run_remaining;

    if (segment_samples > max_segment_samples)
    {
        segment_samples = max_segment_samples;
    }

    phase_before_segment = timer_phase;

    /*
        max_segment_samples is constrained in prepare(), so this expression
        remains within uint32_t for supported 22.05/44.1/48 kHz rates.
    */
    numerator = ((uint32_t)segment_samples * (uint32_t)F_CPU) + timer_phase;
    ticks = numerator / timer_rate;
    timer_phase = numerator % timer_rate;

    if ((ticks == 0) || (ticks > 65536UL))
    {
        return false;
    }

    active_run_remaining = (uint16_t)(active_run_remaining - segment_samples);
    scheduled_segment_samples = segment_samples;
    OCR5A = (uint16_t)(ticks - 1U);
    return true;
}

static bool wav_playback_start_or_continue_run(bool from_isr)
{
    if (!active_run_valid || (active_run_remaining == 0))
    {
        active_run_valid = false;

        if (!wav_playback_load_next_run(from_isr))
        {
            return false;
        }
    }

    return wav_playback_schedule_active_run_segment();
}

/* Timer is started only after OCR5A and the first run are ready. */
static void wav_playback_enable_timer_from_foreground(void)
{
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        TCNT5 = 0;
        TIFR5 = _BV(OCF5A);
        driver_state = WAV_PLAYBACK_DRIVER_RUNNING;
        TIMSK5 |= _BV(OCIE5A);
        TCCR5B = _BV(WGM52) | _BV(CS50);
    }
}

void wav_playback_driver_init(void)
{
    uint8_t port = digitalPinToPort(WAV_PLAYBACK_READ_PIN);

    pinMode(WAV_PLAYBACK_READ_PIN, OUTPUT);
    digitalWrite(WAV_PLAYBACK_READ_PIN, LOW);

    if (port == NOT_A_PIN)
    {
        driver_state = WAV_PLAYBACK_DRIVER_BAD_ARGUMENT;
        return;
    }

    read_output_port = portOutputRegister(port);
    read_output_mask = digitalPinToBitMask(WAV_PLAYBACK_READ_PIN);

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        TCCR5A = 0;
        TCCR5B = _BV(WGM52);
        TCNT5 = 0;
        OCR5A = 0xFFFF;
        TIMSK5 &= (uint8_t)~_BV(OCIE5A);
        TIFR5 = _BV(OCF5A);
    }

    pop_run_callback = NULL;
    source_finished_callback = NULL;
    timer_rate = 0;
    timer_phase = 0;
    max_segment_samples = 0;
    active_run_remaining = 0;
    scheduled_segment_samples = 0;
    phase_before_segment = 0;
    active_run_valid = false;
    current_output_level = 0;
    output_edge_count = 0;
    driver_state = WAV_PLAYBACK_DRIVER_STOPPED;
}

bool wav_playback_driver_prepare(uint32_t sample_rate,
                                 wav_playback_pop_run_fn pop_run,
                                 wav_playback_source_finished_fn source_finished)
{
    uint32_t maximum_samples;

    if ((read_output_port == NULL) ||
        (sample_rate == 0) ||
        (pop_run == NULL) ||
        (source_finished == NULL))
    {
        driver_state = WAV_PLAYBACK_DRIVER_BAD_ARGUMENT;
        return false;
    }

    /*
        Maximum N where N*F_CPU/sample_rate fits into the 16-bit CTC period.
        For 44.1 kHz it is 180 samples ≈ 4.08 ms.
    */
    maximum_samples = (65535UL * sample_rate) / (uint32_t)F_CPU;

    if ((maximum_samples == 0) || (maximum_samples > 65535UL))
    {
        driver_state = WAV_PLAYBACK_DRIVER_BAD_RATE;
        return false;
    }

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        TCCR5B = _BV(WGM52);
        TIMSK5 &= (uint8_t)~_BV(OCIE5A);
        TIFR5 = _BV(OCF5A);
        TCNT5 = 0;

        timer_rate = sample_rate;
        timer_phase = 0;
        max_segment_samples = (uint16_t)maximum_samples;
        active_run_remaining = 0;
        scheduled_segment_samples = 0;
        phase_before_segment = 0;
        active_run_valid = false;
        output_edge_count = 0;

        pop_run_callback = pop_run;
        source_finished_callback = source_finished;
        driver_state = WAV_PLAYBACK_DRIVER_READY;
    }

    return true;
}

bool wav_playback_driver_start(void)
{
    if (wav_playback_state_snapshot() != WAV_PLAYBACK_DRIVER_READY)
    {
        return false;
    }

    if (!wav_playback_start_or_continue_run(false))
    {
        driver_state = source_finished_callback() ?
            WAV_PLAYBACK_DRIVER_FINISHED : WAV_PLAYBACK_DRIVER_UNDERRUN;
        return false;
    }

    wav_playback_enable_timer_from_foreground();

    return true;
}

bool wav_playback_driver_pause(void)
{
    wav_playback_driver_state_t state = wav_playback_state_snapshot();

    if ((state != WAV_PLAYBACK_DRIVER_RUNNING) &&
        (state != WAV_PLAYBACK_DRIVER_WAITING_DATA))
    {
        return false;
    }

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        /*
            The currently programmed segment has not necessarily elapsed.
            Restore it so resume does not lose any WAV samples. A WAITING_DATA
            state has no scheduled segment, so nothing is restored there.
        */
        if (scheduled_segment_samples != 0)
        {
            active_run_remaining = (uint16_t)(
                active_run_remaining + scheduled_segment_samples
            );
            timer_phase = phase_before_segment;
            scheduled_segment_samples = 0;
        }

        TCCR5B = _BV(WGM52);
        TIMSK5 &= (uint8_t)~_BV(OCIE5A);
        TIFR5 = _BV(OCF5A);
        driver_state = WAV_PLAYBACK_DRIVER_PAUSED;
    }

    return true;
}

bool wav_playback_driver_resume(void)
{
    if (wav_playback_state_snapshot() != WAV_PLAYBACK_DRIVER_PAUSED)
    {
        return false;
    }

    if (!wav_playback_start_or_continue_run(false))
    {
        /*
            Resume can race the foreground producer. Treat an empty queue as
            recoverable until the producer confirms physical WAV EOF.
        */
        driver_state = source_finished_callback() ?
            WAV_PLAYBACK_DRIVER_FINISHED : WAV_PLAYBACK_DRIVER_WAITING_DATA;
        return true;
    }

    wav_playback_enable_timer_from_foreground();
    return true;
}

bool wav_playback_driver_continue_after_wait(void)
{
    if (wav_playback_state_snapshot() != WAV_PLAYBACK_DRIVER_WAITING_DATA)
    {
        return false;
    }

    if (!wav_playback_start_or_continue_run(false))
    {
        /* No new run is visible yet. Foreground code may try again later. */
        return false;
    }

    wav_playback_enable_timer_from_foreground();
    return true;
}

void wav_playback_driver_stop(void)
{
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        TCCR5B = _BV(WGM52);
        TIMSK5 &= (uint8_t)~_BV(OCIE5A);
        TIFR5 = _BV(OCF5A);
        driver_state = WAV_PLAYBACK_DRIVER_STOPPED;
        active_run_remaining = 0;
        scheduled_segment_samples = 0;
        active_run_valid = false;
    }

    if (read_output_port != NULL)
    {
        *read_output_port &= (uint8_t)~read_output_mask;
    }

    current_output_level = 0;
    pop_run_callback = NULL;
    source_finished_callback = NULL;
}

wav_playback_driver_state_t wav_playback_driver_get_state(void)
{
    return wav_playback_state_snapshot();
}

uint32_t wav_playback_driver_get_sample_rate(void)
{
    uint32_t sample_rate;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        sample_rate = timer_rate;
    }

    return sample_rate;
}

uint8_t wav_playback_driver_get_read_pin(void)
{
    return WAV_PLAYBACK_READ_PIN;
}

uint16_t wav_playback_driver_get_edge_count(void)
{
    uint16_t edge_count;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        edge_count = output_edge_count;
    }

    return edge_count;
}

ISR(TIMER5_COMPA_vect)
{
    if ((driver_state != WAV_PLAYBACK_DRIVER_RUNNING) ||
        (pop_run_callback == NULL) ||
        (source_finished_callback == NULL))
    {
        wav_playback_disable_timer_from_isr();
        driver_state = WAV_PLAYBACK_DRIVER_BAD_ARGUMENT;
        return;
    }

    /*
        The programmed segment has elapsed. Continue its run, or load a new
        edge run. In the normal CMT case this ISR executes once per edge.
    */
    scheduled_segment_samples = 0;

    if (!wav_playback_start_or_continue_run(true))
    {
        wav_playback_disable_timer_from_isr();

        /*
            The producer may be between its final data block and EOF
            publication. Do not turn that normal end-of-file race into an
            UNDERRUN. Foreground play_engine_service() will either refill one
            more run or confirm EOF and return the UI to RDY.
        */
        driver_state = source_finished_callback() ?
            WAV_PLAYBACK_DRIVER_FINISHED : WAV_PLAYBACK_DRIVER_WAITING_DATA;
    }
}
