#include "wav_record_engine.h"

#include <stdio.h>
#include <string.h>

#include "../drivers/sdcard.h"
#include "../drivers/wav_record_driver.h"
#include "../streams/record_sample_stream.h"

#define WAV_RECORD_PATH_MAX 160U
#define WAV_RECORD_FILENAME_MAX 16U

/*
    Data starts at byte 512 rather than byte 44. The standard RIFF fmt chunk
    is followed by a legal JUNK chunk, then the data chunk. This makes every
    512-byte PCM write sector-aligned, avoiding constant read-modify-write
    cache work on the SD card.
*/
#define WAV_RECORD_HEADER_BYTES 512U
#define WAV_RECORD_DATA_OFFSET WAV_RECORD_HEADER_BYTES
#define WAV_RECORD_JUNK_PAYLOAD_BYTES 460U

#define WAV_RECORD_PCM_BLOCK_BYTES 512U
#define WAV_RECORD_RAW_BLOCK_BYTES (WAV_RECORD_PCM_BLOCK_BYTES / 8U)

/* About 23.8 s of 44.1 kHz / 8-bit mono. Allocation happens before Timer1. */
#define WAV_RECORD_PREALLOCATE_DATA_BYTES (1024UL * 1024UL)
#define WAV_RECORD_PREALLOCATE_TOTAL_BYTES \
    (WAV_RECORD_DATA_OFFSET + WAV_RECORD_PREALLOCATE_DATA_BYTES)

static wav_record_engine_state_t record_state = WAV_RECORD_ENGINE_STOPPED;

static char record_full_path[WAV_RECORD_PATH_MAX];
static char record_filename[WAV_RECORD_FILENAME_MAX];
static char record_error_text[17];

static uint32_t record_sample_rate = 0UL;
static uint32_t data_bytes_written = 0UL;

static uint8_t raw_block[WAV_RECORD_RAW_BLOCK_BYTES];
/* Reused for sector PCM data and the 512-byte RIFF/JUNK/data header. */
static uint8_t pcm_block[WAV_RECORD_PCM_BLOCK_BYTES];

static bool record_preallocated = false;
static bool final_tail_written = false;
static bool finalization_has_error = false;

static void wav_record_set_error(const char *text)
{
    if (text == NULL)
    {
        record_error_text[0] = '\0';
        return;
    }

    strncpy(record_error_text, text, sizeof(record_error_text) - 1U);
    record_error_text[sizeof(record_error_text) - 1U] = '\0';
}

static void wav_record_put_le16(uint8_t *target, uint16_t value)
{
    target[0] = (uint8_t)(value & 0xFFU);
    target[1] = (uint8_t)((value >> 8) & 0xFFU);
}

static void wav_record_put_le32(uint8_t *target, uint32_t value)
{
    target[0] = (uint8_t)(value & 0xFFUL);
    target[1] = (uint8_t)((value >> 8) & 0xFFUL);
    target[2] = (uint8_t)((value >> 16) & 0xFFUL);
    target[3] = (uint8_t)((value >> 24) & 0xFFUL);
}

static bool wav_record_write_header(uint32_t data_size)
{
    uint32_t riff_size;

    if (data_size > (0xFFFFFFFFUL - (WAV_RECORD_HEADER_BYTES - 8UL)))
    {
        wav_record_set_error("FILE TOO BIG");
        return false;
    }

    /* RIFF size is complete file length minus the first eight bytes. */
    riff_size = data_size + (WAV_RECORD_HEADER_BYTES - 8UL);

    memset(pcm_block, 0, sizeof(pcm_block));

    memcpy(pcm_block + 0U, "RIFF", 4U);
    wav_record_put_le32(pcm_block + 4U, riff_size);
    memcpy(pcm_block + 8U, "WAVE", 4U);

    memcpy(pcm_block + 12U, "fmt ", 4U);
    wav_record_put_le32(pcm_block + 16U, 16UL);
    wav_record_put_le16(pcm_block + 20U, 1U);  /* PCM */
    wav_record_put_le16(pcm_block + 22U, 1U);  /* mono */
    wav_record_put_le32(pcm_block + 24U, record_sample_rate);
    wav_record_put_le32(pcm_block + 28U, record_sample_rate);
    wav_record_put_le16(pcm_block + 32U, 1U);  /* block align */
    wav_record_put_le16(pcm_block + 34U, 8U);  /* unsigned PCM */

    /* 36 + 8 + 460 = 504; the data chunk header then begins at byte 504. */
    memcpy(pcm_block + 36U, "JUNK", 4U);
    wav_record_put_le32(pcm_block + 40U, WAV_RECORD_JUNK_PAYLOAD_BYTES);

    memcpy(pcm_block + 504U, "data", 4U);
    wav_record_put_le32(pcm_block + 508U, data_size);

    if (!sdcard_file_seek(0UL) ||
        (sdcard_file_write(pcm_block, sizeof(pcm_block)) !=
         (int16_t)sizeof(pcm_block)))
    {
        wav_record_set_error("WAV HEADER ERR");
        return false;
    }

    return true;
}

static bool wav_record_make_path(const char *directory_path)
{
    if ((directory_path == NULL) || (directory_path[0] == '\0'))
    {
        wav_record_set_error("BAD DIRECTORY");
        return false;
    }

    for (uint16_t index = 1U; index <= 9999U; index++)
    {
        int path_length;

        if (strcmp(directory_path, "/") == 0)
        {
            path_length = snprintf(record_full_path,
                                   sizeof(record_full_path),
                                   "/REC%04u.WAV",
                                   (unsigned int)index);
        }
        else
        {
            path_length = snprintf(record_full_path,
                                   sizeof(record_full_path),
                                   "%s/REC%04u.WAV",
                                   directory_path,
                                   (unsigned int)index);
        }

        if ((path_length <= 0) ||
            ((size_t)path_length >= sizeof(record_full_path)))
        {
            wav_record_set_error("PATH TOO LONG");
            return false;
        }

        if (!sdcard_file_exists(record_full_path))
        {
            snprintf(record_filename,
                     sizeof(record_filename),
                     "REC%04u.WAV",
                     (unsigned int)index);
            return true;
        }
    }

    wav_record_set_error("REC NAMES FULL");
    return false;
}

static uint16_t wav_record_expand_to_pcm(const uint8_t *packed,
                                         uint16_t byte_count,
                                         uint8_t valid_last_bits)
{
    uint16_t output_count = 0U;

    for (uint16_t byte_index = 0U; byte_index < byte_count; byte_index++)
    {
        uint8_t bits = 8U;

        if ((byte_index == (uint16_t)(byte_count - 1U)) &&
            (valid_last_bits != 0U) &&
            (valid_last_bits < 8U))
        {
            bits = valid_last_bits;
        }

        for (uint8_t bit = 0U; bit < bits; bit++)
        {
            pcm_block[output_count++] =
                (packed[byte_index] & (uint8_t)(1U << bit)) ? 235U : 20U;
        }
    }

    return output_count;
}

/*
    During recording only complete 64-byte raw blocks are drained. That makes
    every normal SD write exactly 512 PCM bytes. Draining one or two raw bytes
    per service call was the v0.16 throughput failure at 44.1 kHz.
*/
static bool wav_record_drain_block(bool allow_partial)
{
    uint16_t available;
    uint16_t request;
    uint16_t raw_count;
    uint16_t pcm_count;

    available = record_sample_stream_available_bytes();

    if (available == 0U)
    {
        return true;
    }

    if (!allow_partial && (available < WAV_RECORD_RAW_BLOCK_BYTES))
    {
        return true;
    }

    request = allow_partial ? available : WAV_RECORD_RAW_BLOCK_BYTES;

    if (request > WAV_RECORD_RAW_BLOCK_BYTES)
    {
        request = WAV_RECORD_RAW_BLOCK_BYTES;
    }

    raw_count = record_sample_stream_pop_bytes(raw_block, request);

    if (raw_count == 0U)
    {
        return true;
    }

    if (!allow_partial && (raw_count != WAV_RECORD_RAW_BLOCK_BYTES))
    {
        wav_record_set_error("REC FIFO RACE");
        return false;
    }

    pcm_count = wav_record_expand_to_pcm(raw_block, raw_count, 8U);

    if ((pcm_count == 0U) ||
        (sdcard_file_write(pcm_block, pcm_count) != (int16_t)pcm_count))
    {
        wav_record_set_error("SD WRITE ERROR");
        return false;
    }

    data_bytes_written += (uint32_t)pcm_count;
    return true;
}

static bool wav_record_drain_ready_blocks(void)
{
    while (record_sample_stream_available_bytes() >=
           WAV_RECORD_RAW_BLOCK_BYTES)
    {
        if (!wav_record_drain_block(false))
        {
            return false;
        }
    }

    return true;
}

static bool wav_record_drain_all_remaining(void)
{
    while (record_sample_stream_available_bytes() != 0U)
    {
        if (!wav_record_drain_block(true))
        {
            return false;
        }
    }

    return true;
}

static bool wav_record_write_tail(void)
{
    uint8_t packed_byte;
    uint8_t valid_bits;
    uint16_t pcm_count;

    if (final_tail_written)
    {
        return true;
    }

    final_tail_written = true;

    if (!wav_record_driver_take_tail(&packed_byte, &valid_bits))
    {
        return true;
    }

    raw_block[0] = packed_byte;
    pcm_count = wav_record_expand_to_pcm(raw_block, 1U, valid_bits);

    if ((pcm_count == 0U) ||
        (sdcard_file_write(pcm_block, pcm_count) != (int16_t)pcm_count))
    {
        wav_record_set_error("SD WRITE ERROR");
        return false;
    }

    data_bytes_written += (uint32_t)pcm_count;
    return true;
}

static void wav_record_close_with_error(void)
{
    wav_record_driver_stop();
    sdcard_file_close();
    record_state = WAV_RECORD_ENGINE_ERROR;
}

void wav_record_engine_init(void)
{
    wav_record_driver_init();

    record_state = WAV_RECORD_ENGINE_STOPPED;
    record_full_path[0] = '\0';
    record_filename[0] = '\0';
    record_error_text[0] = '\0';
    record_sample_rate = 0UL;
    data_bytes_written = 0UL;
    record_preallocated = false;
    final_tail_written = false;
    finalization_has_error = false;
}

bool wav_record_engine_start(const char *directory_path,
                             uint32_t sample_rate)
{
    wav_record_engine_init();

    if (!sdcard_is_mounted())
    {
        wav_record_set_error("SD CARD ERROR");
        record_state = WAV_RECORD_ENGINE_ERROR;
        return false;
    }

    if (!wav_record_driver_prepare(sample_rate))
    {
        wav_record_set_error("BAD REC RATE");
        record_state = WAV_RECORD_ENGINE_ERROR;
        return false;
    }

    record_sample_rate = sample_rate;

    if (!wav_record_make_path(directory_path))
    {
        record_state = WAV_RECORD_ENGINE_ERROR;
        return false;
    }

    if (!sdcard_file_open_write(record_full_path))
    {
        wav_record_set_error("FILE CREATE ERR");
        record_state = WAV_RECORD_ENGINE_ERROR;
        return false;
    }

    /*
        Preallocation is a reliability enhancement. It is deliberately not a
        hard requirement: a fragmented/near-full card can still record, but
        may have less protection against filesystem allocation stalls.
    */
    record_preallocated = sdcard_file_preallocate(
        WAV_RECORD_PREALLOCATE_TOTAL_BYTES
    );

    if (!wav_record_write_header(0UL) ||
        !sdcard_file_seek(WAV_RECORD_DATA_OFFSET))
    {
        wav_record_close_with_error();
        return false;
    }

    if (!wav_record_driver_start())
    {
        wav_record_set_error("REC TIMER ERR");
        wav_record_close_with_error();
        return false;
    }

    record_state = WAV_RECORD_ENGINE_RECORDING;
    return true;
}

void wav_record_engine_request_stop(void)
{
    if (record_state != WAV_RECORD_ENGINE_RECORDING)
    {
        return;
    }

    wav_record_driver_stop();
    record_state = WAV_RECORD_ENGINE_FINALIZING;
}

void wav_record_engine_service(void)
{
    wav_record_driver_state_t driver_state;

    if (record_state == WAV_RECORD_ENGINE_RECORDING)
    {
        driver_state = wav_record_driver_get_state();

        if (driver_state == WAV_RECORD_DRIVER_OVERRUN)
        {
            wav_record_set_error("REC OVERFLOW");
            finalization_has_error = true;
            wav_record_driver_stop();
            record_state = WAV_RECORD_ENGINE_FINALIZING;
            return;
        }

        if (!wav_record_drain_ready_blocks())
        {
            wav_record_close_with_error();
        }

        return;
    }

    if (record_state != WAV_RECORD_ENGINE_FINALIZING)
    {
        return;
    }

    if (!wav_record_drain_all_remaining())
    {
        wav_record_close_with_error();
        return;
    }

    if (!wav_record_write_tail())
    {
        wav_record_close_with_error();
        return;
    }

    if (record_preallocated)
    {
        uint32_t final_length;

        if (data_bytes_written >
            (0xFFFFFFFFUL - WAV_RECORD_DATA_OFFSET))
        {
            wav_record_set_error("FILE TOO BIG");
            wav_record_close_with_error();
            return;
        }

        final_length = WAV_RECORD_DATA_OFFSET + data_bytes_written;

        if (!sdcard_file_truncate(final_length))
        {
            wav_record_set_error("FILE TRUNC ERR");
            wav_record_close_with_error();
            return;
        }
    }

    if (!wav_record_write_header(data_bytes_written) ||
        !sdcard_file_sync())
    {
        wav_record_close_with_error();
        return;
    }

    sdcard_file_close();

    record_state = finalization_has_error ?
        WAV_RECORD_ENGINE_ERROR : WAV_RECORD_ENGINE_FINISHED;
}

wav_record_engine_state_t wav_record_engine_get_state(void)
{
    return record_state;
}

const char *wav_record_engine_get_filename(void)
{
    return record_filename;
}

const char *wav_record_engine_get_full_path(void)
{
    return record_full_path;
}

const char *wav_record_engine_get_error_text(void)
{
    return record_error_text;
}

uint32_t wav_record_engine_get_sample_rate(void)
{
    return record_sample_rate;
}

uint32_t wav_record_engine_get_captured_samples(void)
{
    uint32_t queued =
        (uint32_t)record_sample_stream_available_bytes() * 8UL;
    uint32_t pending =
        (uint32_t)wav_record_driver_get_pending_sample_count();

    return data_bytes_written + queued + pending;
}

uint8_t wav_record_engine_get_buffer_fill_percent(void)
{
    return record_sample_stream_fill_percent();
}

uint8_t wav_record_engine_get_write_pin(void)
{
    return wav_record_driver_get_write_pin();
}
