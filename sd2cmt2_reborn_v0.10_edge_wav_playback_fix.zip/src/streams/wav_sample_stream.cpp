#include "wav_sample_stream.h"

#include <stddef.h>
#include <string.h>

#include <Arduino.h>
#include <util/atomic.h>

#if ((WAV_SAMPLE_STREAM_RUN_CAPACITY & (WAV_SAMPLE_STREAM_RUN_CAPACITY - 1U)) != 0)
#error "WAV_SAMPLE_STREAM_RUN_CAPACITY must be a power of two"
#endif

#if (WAV_SAMPLE_STREAM_RUN_USABLE > 32767U)
#error "WAV run ring must be <= 32767 usable entries"
#endif

#define WAV_SAMPLE_STREAM_RUN_MASK (WAV_SAMPLE_STREAM_RUN_CAPACITY - 1U)

/*
    Producer owns write_sequence. Timer5 ISR owns read_sequence.
    A run becomes visible to the ISR only after its complete payload is stored.
*/
static wav_sample_run_t run_ring[WAV_SAMPLE_STREAM_RUN_CAPACITY];
static uint8_t raw_buffer[WAV_SAMPLE_STREAM_RAW_BLOCK];

static volatile uint16_t read_sequence = 0;
static volatile uint16_t write_sequence = 0;

static uint16_t raw_count = 0;
static uint16_t raw_index = 0;
static bool raw_eof = false;

static bool pending_valid = false;
static uint16_t pending_samples = 0;
static uint8_t pending_level = 0;

static bool input_level = false;
static volatile bool source_finished = false;

static wav_sample_stream_config_t stream_config =
{
    100,
    155,
    false
};

static wav_reader_info_t stream_info;
static wav_reader_status_t stream_status = WAV_READER_STATUS_BAD_ARGUMENT;

static uint16_t wav_sample_stream_available_runs_snapshot(void)
{
    uint16_t read_snapshot;
    uint16_t write_snapshot;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        read_snapshot = read_sequence;
        write_snapshot = write_sequence;
    }

    return (uint16_t)(write_snapshot - read_snapshot);
}

static uint8_t wav_sample_stream_decode_level(uint8_t sample)
{
    /*
        The middle hysteresis zone always preserves the last state.
        No per-sample ambiguity reaches the timing driver.
    */
    if (!input_level)
    {
        if (sample >= stream_config.high_threshold)
        {
            input_level = true;
        }
    }
    else if (sample <= stream_config.low_threshold)
    {
        input_level = false;
    }

    return (uint8_t)((input_level ^ stream_config.invert_signal) ? 1U : 0U);
}

static bool wav_sample_stream_ring_has_room(void)
{
    return wav_sample_stream_available_runs_snapshot() <
           WAV_SAMPLE_STREAM_RUN_USABLE;
}

static bool wav_sample_stream_publish_pending(void)
{
    uint16_t write_snapshot;

    if (!pending_valid)
    {
        return true;
    }

    if (!wav_sample_stream_ring_has_room())
    {
        return false;
    }

    /*
        Read write_sequence atomically, write the event, then publish it in a
        short critical section. The ISR can never see a partially written run.
    */
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        write_snapshot = write_sequence;
    }

    run_ring[write_snapshot & WAV_SAMPLE_STREAM_RUN_MASK].samples =
        pending_samples;
    run_ring[write_snapshot & WAV_SAMPLE_STREAM_RUN_MASK].level =
        pending_level;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        write_sequence = (uint16_t)(write_snapshot + 1U);
    }

    pending_valid = false;
    pending_samples = 0;
    return true;
}

static int16_t wav_sample_stream_read_raw_sample(void)
{
    int16_t received;

    if (raw_index < raw_count)
    {
        return raw_buffer[raw_index++];
    }

    if (raw_eof)
    {
        return -1;
    }

    received = wav_reader_read_samples(raw_buffer, sizeof(raw_buffer));

    if (received < 0)
    {
        stream_status = wav_reader_last_status();
        return -2;
    }

    if (received == 0)
    {
        raw_eof = true;
        raw_count = 0;
        raw_index = 0;
        return -1;
    }

    raw_count = (uint16_t)received;
    raw_index = 0;

    return raw_buffer[raw_index++];
}

static bool wav_sample_stream_finish_source(void)
{
    if (!raw_eof)
    {
        return true;
    }

    if (!wav_sample_stream_publish_pending())
    {
        /*
            EOF arrived while the run ring is full. This is not an I/O error:
            preserve the pending final run and publish it after Timer5 consumes
            one slot during a later foreground refill.
        */
        return true;
    }

    source_finished = true;
    return true;
}

bool wav_sample_stream_open(const char *path,
                            const wav_sample_stream_config_t *config)
{
    if ((path == NULL) ||
        (config == NULL) ||
        (config->low_threshold >= config->high_threshold))
    {
        stream_status = WAV_READER_STATUS_BAD_ARGUMENT;
        return false;
    }

    wav_sample_stream_close();

    stream_config = *config;
    input_level = false;
    raw_count = 0;
    raw_index = 0;
    raw_eof = false;
    pending_valid = false;
    pending_samples = 0;
    pending_level = 0;
    source_finished = false;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        read_sequence = 0;
        write_sequence = 0;
    }

    if (!wav_reader_open(path, &stream_info))
    {
        stream_status = wav_reader_last_status();
        return false;
    }

    stream_status = WAV_READER_STATUS_OK;
    return true;
}

void wav_sample_stream_close(void)
{
    wav_reader_close();

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        read_sequence = 0;
        write_sequence = 0;
    }

    raw_count = 0;
    raw_index = 0;
    raw_eof = false;
    pending_valid = false;
    pending_samples = 0;
    pending_level = 0;
    input_level = false;
    source_finished = true;
}

bool wav_sample_stream_refill_block(void)
{
    uint16_t processed = 0;

    if (source_finished)
    {
        return true;
    }

    if (!wav_reader_is_open())
    {
        stream_status = wav_reader_last_status();
        return false;
    }

    /*
        Bounded work per service call. Keeping it to one raw block prevents
        foreground refill from delaying UI or a future MOTOR state handler.
    */
    while (processed < WAV_SAMPLE_STREAM_RAW_BLOCK)
    {
        int16_t raw_sample;
        uint8_t level;

        /*
            One free event is required before consuming another sample because
            that sample may end the pending run. Stop before overwriting it.
        */
        if (pending_valid && !wav_sample_stream_ring_has_room())
        {
            break;
        }

        raw_sample = wav_sample_stream_read_raw_sample();

        if (raw_sample == -2)
        {
            return false;
        }

        if (raw_sample == -1)
        {
            return wav_sample_stream_finish_source();
        }

        level = wav_sample_stream_decode_level((uint8_t)raw_sample);
        processed++;

        if (!pending_valid)
        {
            pending_valid = true;
            pending_level = level;
            pending_samples = 1;
            continue;
        }

        if ((level == pending_level) &&
            (pending_samples < WAV_SAMPLE_STREAM_MAX_RUN_SAMPLES))
        {
            pending_samples++;

            /*
                Publish immediately at the bound. This also lets a completely
                flat WAV produce a valid initial run without scanning its
                entire data chunk at prepare time.
            */
            if (pending_samples >= WAV_SAMPLE_STREAM_MAX_RUN_SAMPLES)
            {
                if (!wav_sample_stream_publish_pending())
                {
                    stream_status = WAV_READER_STATUS_IO_ERROR;
                    return false;
                }
            }

            continue;
        }

        if (!wav_sample_stream_publish_pending())
        {
            stream_status = WAV_READER_STATUS_IO_ERROR;
            return false;
        }

        pending_valid = true;
        pending_level = level;
        pending_samples = 1;
    }

    return true;
}

bool wav_sample_stream_prefill(uint16_t target_runs)
{
    if (target_runs == 0)
    {
        target_runs = 1;
    }

    if (target_runs > WAV_SAMPLE_STREAM_RUN_USABLE)
    {
        target_runs = WAV_SAMPLE_STREAM_RUN_USABLE;
    }

    while (!source_finished &&
           (wav_sample_stream_available_runs_snapshot() < target_runs))
    {
        uint16_t before = wav_sample_stream_available_runs_snapshot();

        if (!wav_sample_stream_refill_block())
        {
            return false;
        }

        if (wav_sample_stream_available_runs_snapshot() == before &&
            !source_finished)
        {
            /*
                Ring became full only through a pending run boundary, or no
                new boundary exists in this raw block. The next foreground
                service call will continue safely.
            */
            break;
        }
    }

    return wav_sample_stream_available_runs_snapshot() > 0;
}

static bool wav_sample_stream_pop_run_internal(uint16_t *samples,
                                               uint8_t *level)
{
    uint16_t read_snapshot;
    wav_sample_run_t run;

    if ((samples == NULL) || (level == NULL))
    {
        return false;
    }

    read_snapshot = read_sequence;

    if (read_snapshot == write_sequence)
    {
        return false;
    }

    run = run_ring[read_snapshot & WAV_SAMPLE_STREAM_RUN_MASK];

    *samples = run.samples;
    *level = run.level;

    read_sequence = (uint16_t)(read_snapshot + 1U);
    return (run.samples != 0);
}

bool wav_sample_stream_pop_run(uint16_t *samples, uint8_t *level)
{
    bool result;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        result = wav_sample_stream_pop_run_internal(samples, level);
    }

    return result;
}

bool wav_sample_stream_pop_run_from_isr(uint16_t *samples, uint8_t *level)
{
    return wav_sample_stream_pop_run_internal(samples, level);
}

uint16_t wav_sample_stream_available_runs(void)
{
    return wav_sample_stream_available_runs_snapshot();
}

bool wav_sample_stream_source_finished(void)
{
    return source_finished;
}

bool wav_sample_stream_finished(void)
{
    return source_finished &&
           (wav_sample_stream_available_runs_snapshot() == 0);
}

bool wav_sample_stream_finished_from_isr(void)
{
    return source_finished && (read_sequence == write_sequence);
}

const wav_reader_info_t *wav_sample_stream_info(void)
{
    return wav_reader_is_open() ? &stream_info : NULL;
}

wav_reader_status_t wav_sample_stream_last_status(void)
{
    return stream_status;
}
