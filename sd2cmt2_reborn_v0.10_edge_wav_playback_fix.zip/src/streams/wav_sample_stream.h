#ifndef SD2CMT2_WAV_SAMPLE_STREAM_H
#define SD2CMT2_WAV_SAMPLE_STREAM_H

#include <stdbool.h>
#include <stdint.h>

#include "../formats/wav_reader.h"

/*
    WAV playback is an edge/run stream, not a 44.1 kHz byte stream.

    Every event means:
        keep READ at level for samples samples.

    The incoming 8-bit WAV data is thresholded with hysteresis in foreground
    code and compressed into runs. Timer5 will therefore run only at output
    transitions (and only occasionally inside an unusually long constant run),
    never once for every input sample.

    512 events × 3 packed bytes = 1536 bytes.
    A separate 512 byte input block keeps total stream SRAM at 2048 bytes.
*/
#define WAV_SAMPLE_STREAM_RUN_CAPACITY 512U
#define WAV_SAMPLE_STREAM_RUN_USABLE   (WAV_SAMPLE_STREAM_RUN_CAPACITY - 1U)
#define WAV_SAMPLE_STREAM_RAW_BLOCK    512U

/*
    Long flat areas are deliberately split. This prevents a minute-long DC WAV
    from being read completely during prepare and bounds a timer segment.
*/
#define WAV_SAMPLE_STREAM_MAX_RUN_SAMPLES 512U

typedef struct __attribute__((packed))
{
    uint16_t samples;
    uint8_t level;

} wav_sample_run_t;

typedef struct
{
    uint8_t low_threshold;
    uint8_t high_threshold;
    bool invert_signal;

} wav_sample_stream_config_t;

bool wav_sample_stream_open(const char *path,
                            const wav_sample_stream_config_t *config);

void wav_sample_stream_close(void);

/*
    Foreground producer. Each call processes up to one 512 byte raw block.
    It may be called frequently from play_engine_service().
*/
bool wav_sample_stream_refill_block(void);

/*
    Prepare enough output runs for startup. It stops at target_runs, physical
    source end, or a full event ring. Never call from a timer ISR.
*/
bool wav_sample_stream_prefill(uint16_t target_runs);

/*
    Run consumers. The _from_isr form performs no atomic block because a timer
    ISR already executes with interrupts masked.
*/
bool wav_sample_stream_pop_run(uint16_t *samples, uint8_t *level);
bool wav_sample_stream_pop_run_from_isr(uint16_t *samples, uint8_t *level);

uint16_t wav_sample_stream_available_runs(void);
bool wav_sample_stream_source_finished(void);
bool wav_sample_stream_finished(void);
bool wav_sample_stream_finished_from_isr(void);

const wav_reader_info_t *wav_sample_stream_info(void);
wav_reader_status_t wav_sample_stream_last_status(void);

#endif
