#ifndef SD2CMT2_WAV_PLAYBACK_DRIVER_H
#define SD2CMT2_WAV_PLAYBACK_DRIVER_H

#include <stdbool.h>
#include <stdint.h>

/*
    Arduino Mega 2560 default: digital pin 2 is the historic Sharp CMT READ
    output (OC3B / PE4). Override it in platformio.ini if this Reborn hardware
    uses another physical READ pin, for example:

        build_flags = -DWAV_PLAYBACK_READ_PIN=2
*/
#ifndef WAV_PLAYBACK_READ_PIN
#define WAV_PLAYBACK_READ_PIN 2
#endif

typedef bool (*wav_playback_pop_sample_fn)(uint8_t *level);
typedef bool (*wav_playback_source_finished_fn)(void);

typedef enum
{
    WAV_PLAYBACK_DRIVER_STOPPED = 0,
    WAV_PLAYBACK_DRIVER_READY,
    WAV_PLAYBACK_DRIVER_RUNNING,
    WAV_PLAYBACK_DRIVER_PAUSED,
    WAV_PLAYBACK_DRIVER_FINISHED,
    WAV_PLAYBACK_DRIVER_UNDERRUN,
    WAV_PLAYBACK_DRIVER_BAD_RATE,
    WAV_PLAYBACK_DRIVER_BAD_ARGUMENT
} wav_playback_driver_state_t;

/* Configure Timer5 in CTC mode. IRQ stays disabled until start(). */
void wav_playback_driver_init(void);

bool wav_playback_driver_prepare(uint32_t sample_rate,
                                 wav_playback_pop_sample_fn pop_sample,
                                 wav_playback_source_finished_fn source_finished);

bool wav_playback_driver_start(void);
bool wav_playback_driver_pause(void);
bool wav_playback_driver_resume(void);
void wav_playback_driver_stop(void);

wav_playback_driver_state_t wav_playback_driver_get_state(void);

uint32_t wav_playback_driver_get_sample_rate(void);

#endif
