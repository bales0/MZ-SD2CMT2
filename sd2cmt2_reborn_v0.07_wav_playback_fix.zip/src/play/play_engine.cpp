#include <Arduino.h>
#include <string.h>

#include "play_engine.h"
#include "../drivers/wav_playback_driver.h"
#include "../streams/wav_sample_stream.h"

#define PLAY_ENGINE_PATH_MAX 160
#define PLAY_ENGINE_ERROR_TEXT_MAX 13

/* At 44.1 kHz, 896 prepared samples equal about 20 ms reserve. */
#define WAV_STREAM_REFILL_LOW_WATERMARK 896U
#define WAV_STREAM_REFILL_TARGET        960U

static char prepared_full_path[PLAY_ENGINE_PATH_MAX];
static file_format_t prepared_format = FILE_FORMAT_UNKNOWN;
static menu_play_mode_t prepared_play_mode = MENU_PLAY_MODE_NORMAL;
static bool prepared_invert_signal = false;
static play_engine_state_t engine_state = PLAY_ENGINE_STATE_STOPPED;
static char engine_error_text[PLAY_ENGINE_ERROR_TEXT_MAX] = "";

static void play_engine_clear_error(void)
{
    engine_error_text[0] = '\0';
}

static void play_engine_set_error(const char *text)
{
    if (text == NULL)
    {
        text = "UNKNOWN";
    }

    strncpy(engine_error_text, text, sizeof(engine_error_text) - 1U);
    engine_error_text[sizeof(engine_error_text) - 1U] = '\0';
    engine_state = PLAY_ENGINE_STATE_ERROR;
}

static const char *play_engine_driver_error_text(wav_playback_driver_state_t state)
{
    switch (state)
    {
        case WAV_PLAYBACK_DRIVER_UNDERRUN: return "UNDERRUN";
        case WAV_PLAYBACK_DRIVER_BAD_RATE: return "BAD TIMER";
        case WAV_PLAYBACK_DRIVER_BAD_ARGUMENT: return "TIMER ARG";
        default: return "TIMER";
    }
}

static bool play_engine_wav_pop_sample_from_isr(uint8_t *level)
{
    return wav_sample_stream_pop_from_isr(level);
}

static bool play_engine_wav_finished_from_isr(void)
{
    return wav_sample_stream_finished_from_isr();
}

static bool play_engine_prepare_wav(void)
{
    wav_sample_stream_config_t stream_config;
    const wav_reader_info_t *info;

    stream_config.low_threshold = 100;
    stream_config.high_threshold = 155;
    stream_config.invert_signal = prepared_invert_signal;

    if (!wav_sample_stream_open(prepared_full_path, &stream_config))
    {
        play_engine_set_error(wav_reader_status_text(wav_sample_stream_last_status()));
        return false;
    }

    info = wav_sample_stream_info();

    if (info == NULL)
    {
        wav_sample_stream_close();
        play_engine_set_error("NO WAV INFO");
        return false;
    }

    if (!wav_playback_driver_prepare(info->sample_rate,
                                     play_engine_wav_pop_sample_from_isr,
                                     play_engine_wav_finished_from_isr))
    {
        wav_sample_stream_close();
        play_engine_set_error(play_engine_driver_error_text(
            wav_playback_driver_get_state()));
        return false;
    }

    return true;
}

void play_engine_init(void)
{
    prepared_full_path[0] = '\0';
    prepared_format = FILE_FORMAT_UNKNOWN;
    prepared_play_mode = MENU_PLAY_MODE_NORMAL;
    prepared_invert_signal = false;
    engine_state = PLAY_ENGINE_STATE_STOPPED;
    play_engine_clear_error();

    wav_playback_driver_init();
}

bool play_engine_prepare(const play_engine_config_t *config)
{
    play_engine_stop();
    play_engine_clear_error();

    if ((config == NULL) || (config->full_path == NULL) ||
        (config->format == FILE_FORMAT_UNKNOWN))
    {
        play_engine_set_error("BAD SESSION");
        return false;
    }

    strncpy(prepared_full_path, config->full_path, sizeof(prepared_full_path) - 1U);
    prepared_full_path[sizeof(prepared_full_path) - 1U] = '\0';
    prepared_format = config->format;
    prepared_play_mode = config->play_mode;
    prepared_invert_signal = config->invert_signal;

    if ((prepared_format == FILE_FORMAT_WAV) && !play_engine_prepare_wav())
    {
        return false;
    }

    /* Other supported tape formats remain in their existing stub state. */
    engine_state = PLAY_ENGINE_STATE_READY;
    return true;
}

bool play_engine_start(void)
{
    if (engine_state != PLAY_ENGINE_STATE_READY)
    {
        return false;
    }

    if ((prepared_format == FILE_FORMAT_WAV) && !wav_playback_driver_start())
    {
        play_engine_set_error(play_engine_driver_error_text(
            wav_playback_driver_get_state()));
        return false;
    }

    engine_state = PLAY_ENGINE_STATE_RUNNING;
    return true;
}

bool play_engine_pause(void)
{
    if (engine_state != PLAY_ENGINE_STATE_RUNNING)
    {
        return false;
    }

    if ((prepared_format == FILE_FORMAT_WAV) && !wav_playback_driver_pause())
    {
        play_engine_set_error(play_engine_driver_error_text(
            wav_playback_driver_get_state()));
        return false;
    }

    engine_state = PLAY_ENGINE_STATE_PAUSED;
    return true;
}

bool play_engine_resume(void)
{
    if (engine_state != PLAY_ENGINE_STATE_PAUSED)
    {
        return false;
    }

    if ((prepared_format == FILE_FORMAT_WAV) && !wav_playback_driver_resume())
    {
        play_engine_set_error(play_engine_driver_error_text(
            wav_playback_driver_get_state()));
        return false;
    }

    engine_state = PLAY_ENGINE_STATE_RUNNING;
    return true;
}

void play_engine_stop(void)
{
    wav_playback_driver_stop();
    wav_sample_stream_close();

    engine_state = PLAY_ENGINE_STATE_STOPPED;
}

void play_engine_service(void)
{
    if (engine_state != PLAY_ENGINE_STATE_RUNNING)
    {
        return;
    }

    if (prepared_format != FILE_FORMAT_WAV)
    {
        return;
    }

    switch (wav_playback_driver_get_state())
    {
        case WAV_PLAYBACK_DRIVER_RUNNING:
            /*
                Fill to 960 samples, not merely one 64-byte block. This gives
                the SD subsystem a ~20 ms safety margin at 44.1/48 kHz.
            */
            if ((wav_sample_stream_available() < WAV_STREAM_REFILL_LOW_WATERMARK) &&
                !wav_sample_stream_source_finished())
            {
                while ((wav_sample_stream_available() < WAV_STREAM_REFILL_TARGET) &&
                       !wav_sample_stream_source_finished())
                {
                    if (!wav_sample_stream_refill_block())
                    {
                        wav_playback_driver_stop();
                        play_engine_set_error(wav_reader_status_text(
                            wav_sample_stream_last_status()));
                        return;
                    }
                }
            }
            break;

        case WAV_PLAYBACK_DRIVER_FINISHED:
            /* Re-open and prefill so SELECT can immediately replay the WAV. */
            wav_playback_driver_stop();

            if (play_engine_prepare_wav())
            {
                engine_state = PLAY_ENGINE_STATE_READY;
            }
            break;

        case WAV_PLAYBACK_DRIVER_UNDERRUN:
        case WAV_PLAYBACK_DRIVER_BAD_RATE:
        case WAV_PLAYBACK_DRIVER_BAD_ARGUMENT:
            play_engine_set_error(play_engine_driver_error_text(
                wav_playback_driver_get_state()));
            break;

        case WAV_PLAYBACK_DRIVER_READY:
        case WAV_PLAYBACK_DRIVER_PAUSED:
        case WAV_PLAYBACK_DRIVER_STOPPED:
        default:
            break;
    }
}

play_engine_state_t play_engine_get_state(void)
{
    return engine_state;
}

const char *play_engine_get_error_text(void)
{
    return engine_error_text;
}
