#ifndef SD2CMT2_CMT_SAMPLE_STORAGE_H
#define SD2CMT2_CMT_SAMPLE_STORAGE_H

#include <stdint.h>

/*
    Playback and recording are mutually exclusive application modes.

    Their realtime byte rings therefore share the same 2048 bytes of Mega2560
    SRAM. This avoids allocating a second 2 KiB buffer only for RECORD.
*/
#define CMT_SAMPLE_SHARED_BUFFER_BYTES 2048U

typedef union
{
    uint8_t playback_bytes[CMT_SAMPLE_SHARED_BUFFER_BYTES];
    uint8_t record_bytes[CMT_SAMPLE_SHARED_BUFFER_BYTES];

} cmt_sample_shared_storage_t;

extern volatile cmt_sample_shared_storage_t cmt_sample_shared_storage;

#endif
