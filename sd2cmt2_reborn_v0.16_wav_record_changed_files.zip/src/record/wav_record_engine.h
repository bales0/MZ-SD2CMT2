#ifndef SD2CMT2_WAV_RECORD_ENGINE_H
#define SD2CMT2_WAV_RECORD_ENGINE_H

#include <stdbool.h>
#include <stdint.h>

typedef enum
{
    WAV_RECORD_ENGINE_STOPPED = 0,
    WAV_RECORD_ENGINE_RECORDING,
    WAV_RECORD_ENGINE_FINALIZING,
    WAV_RECORD_ENGINE_FINISHED,
    WAV_RECORD_ENGINE_ERROR

} wav_record_engine_state_t;

void wav_record_engine_init(void);

/*
    Starts a new file named REC0001.WAV ... REC9999.WAV in directory_path.
    No existing file is overwritten. Supported rates: 22050 / 44100 Hz.
*/
bool wav_record_engine_start(const char *directory_path,
                             uint32_t sample_rate);

/* Request orderly stop: timer stops, FIFO drains, WAV header is finalized. */
void wav_record_engine_request_stop(void);

/* Foreground only. Call as frequently as possible while RECORD is open. */
void wav_record_engine_service(void);

wav_record_engine_state_t wav_record_engine_get_state(void);

const char *wav_record_engine_get_filename(void);
const char *wav_record_engine_get_full_path(void);
const char *wav_record_engine_get_error_text(void);

uint32_t wav_record_engine_get_sample_rate(void);

/*
    Captured samples includes data already written to SD, queued packed bytes
    and the current partial byte. It is suitable for elapsed-time UI.
*/
uint32_t wav_record_engine_get_captured_samples(void);

uint8_t wav_record_engine_get_buffer_fill_percent(void);
uint8_t wav_record_engine_get_write_pin(void);

#endif
