#include "wav_record_engine.h"

#include <stdio.h>
#include <string.h>

#include "../drivers/sdcard.h"
#include "../drivers/wav_record_driver.h"
#include "../streams/record_sample_stream.h"

#define WAV_RECORD_PATH_MAX 160U
#define WAV_RECORD_FILENAME_MAX 16U
#define WAV_RECORD_PCM_BLOCK_BYTES 512U
#define WAV_RECORD_RAW_BLOCK_BYTES (WAV_RECORD_PCM_BLOCK_BYTES / 8U)

static wav_record_engine_state_t record_state = WAV_RECORD_ENGINE_STOPPED;

static char record_full_path[WAV_RECORD_PATH_MAX];
static char record_filename[WAV_RECORD_FILENAME_MAX];
static char record_error_text[17];

static uint32_t record_sample_rate = 0UL;
static uint32_t data_bytes_written = 0UL;

static uint8_t raw_block[WAV_RECORD_RAW_BLOCK_BYTES];
static uint8_t pcm_block[WAV_RECORD_PCM_BLOCK_BYTES];

static bool final_tail_written = false;
static bool finalization_has_error = false;

static void wav_record_set_error(const char *text)
{
    if (text == NULL)
    {
        record_error_text[0] = '\0';
        return;
    }

    strncpy(record_error_text, text, sizeof(record_error_text) - 1U);
    record_error_text[sizeof(record_error_text) - 1U] = '\0';
}

static void wav_record_put_le16(uint8_t *target, uint16_t value)
{
    target[0] = (uint8_t)(value & 0xFFU);
    target[1] = (uint8_t)((value >> 8) & 0xFFU);
}

static void wav_record_put_le32(uint8_t *target, uint32_t value)
{
    target[0] = (uint8_t)(value & 0xFFUL);
    target[1] = (uint8_t)((value >> 8) & 0xFFUL);
    target[2] = (uint8_t)((value >> 16) & 0xFFUL);
    target[3] = (uint8_t)((value >> 24) & 0xFFUL);
}

static bool wav_record_write_header(uint32_t data_size)
{
    uint8_t header[44];
    uint32_t riff_size;

    if (data_size > (0xFFFFFFFFUL - 36UL))
    {
        wav_record_set_error("FILE TOO BIG");
        return false;
    }

    riff_size = data_size + 36UL;
    memset(header, 0, sizeof(header));

    memcpy(header + 0U, "RIFF", 4U);
    wav_record_put_le32(header + 4U, riff_size);
    memcpy(header + 8U, "WAVE", 4U);

    memcpy(header + 12U, "fmt ", 4U);
    wav_record_put_le32(header + 16U, 16UL);
    wav_record_put_le16(header + 20U, 1U);  /* PCM */
    wav_record_put_le16(header + 22U, 1U);  /* mono */
    wav_record_put_le32(header + 24U, record_sample_rate);
    wav_record_put_le32(header + 28U, record_sample_rate);
    wav_record_put_le16(header + 32U, 1U);  /* block align */
    wav_record_put_le16(header + 34U, 8U);  /* unsigned PCM */

    memcpy(header + 36U, "data", 4U);
    wav_record_put_le32(header + 40U, data_size);

    if (!sdcard_file_seek(0UL) ||
        (sdcard_file_write(header, sizeof(header)) !=
         (int16_t)sizeof(header)))
    {
        wav_record_set_error("WAV HEADER ERR");
        return false;
    }

    return true;
}

static bool wav_record_make_path(const char *directory_path)
{
    if ((directory_path == NULL) || (directory_path[0] == '\0'))
    {
        wav_record_set_error("BAD DIRECTORY");
        return false;
    }

    for (uint16_t index = 1U; index <= 9999U; index++)
    {
        int path_length;

        if (strcmp(directory_path, "/") == 0)
        {
            path_length = snprintf(record_full_path,
                                   sizeof(record_full_path),
                                   "/REC%04u.WAV",
                                   (unsigned int)index);
        }
        else
        {
            path_length = snprintf(record_full_path,
                                   sizeof(record_full_path),
                                   "%s/REC%04u.WAV",
                                   directory_path,
                                   (unsigned int)index);
        }

        if ((path_length <= 0) ||
            ((size_t)path_length >= sizeof(record_full_path)))
        {
            wav_record_set_error("PATH TOO LONG");
            return false;
        }

        if (!sdcard_file_exists(record_full_path))
        {
            snprintf(record_filename,
                     sizeof(record_filename),
                     "REC%04u.WAV",
                     (unsigned int)index);
            return true;
        }
    }

    wav_record_set_error("REC NAMES FULL");
    return false;
}

static uint16_t wav_record_expand_to_pcm(const uint8_t *packed,
                                         uint16_t byte_count,
                                         uint8_t valid_last_bits)
{
    uint16_t output_count = 0U;

    for (uint16_t byte_index = 0U; byte_index < byte_count; byte_index++)
    {
        uint8_t bits = 8U;

        if ((byte_index == (uint16_t)(byte_count - 1U)) &&
            (valid_last_bits != 0U) &&
            (valid_last_bits < 8U))
        {
            bits = valid_last_bits;
        }

        for (uint8_t bit = 0U; bit < bits; bit++)
        {
            pcm_block[output_count++] =
                (packed[byte_index] & (uint8_t)(1U << bit)) ? 235U : 20U;
        }
    }

    return output_count;
}

static bool wav_record_drain_one_block(void)
{
    uint16_t raw_count;
    uint16_t pcm_count;

    raw_count = record_sample_stream_pop_bytes(
        raw_block,
        WAV_RECORD_RAW_BLOCK_BYTES
    );

    if (raw_count == 0U)
    {
        return true;
    }

    pcm_count = wav_record_expand_to_pcm(raw_block, raw_count, 8U);

    if ((pcm_count == 0U) ||
        (sdcard_file_write(pcm_block, pcm_count) != (int16_t)pcm_count))
    {
        wav_record_set_error("SD WRITE ERROR");
        return false;
    }

    data_bytes_written += (uint32_t)pcm_count;
    return true;
}

static bool wav_record_write_tail(void)
{
    uint8_t packed_byte;
    uint8_t valid_bits;
    uint16_t pcm_count;

    if (final_tail_written)
    {
        return true;
    }

    final_tail_written = true;

    if (!wav_record_driver_take_tail(&packed_byte, &valid_bits))
    {
        return true;
    }

    raw_block[0] = packed_byte;
    pcm_count = wav_record_expand_to_pcm(raw_block, 1U, valid_bits);

    if ((pcm_count == 0U) ||
        (sdcard_file_write(pcm_block, pcm_count) != (int16_t)pcm_count))
    {
        wav_record_set_error("SD WRITE ERROR");
        return false;
    }

    data_bytes_written += (uint32_t)pcm_count;
    return true;
}

static void wav_record_close_with_error(void)
{
    wav_record_driver_stop();
    sdcard_file_close();
    record_state = WAV_RECORD_ENGINE_ERROR;
}

void wav_record_engine_init(void)
{
    wav_record_driver_init();

    record_state = WAV_RECORD_ENGINE_STOPPED;
    record_full_path[0] = '\0';
    record_filename[0] = '\0';
    record_error_text[0] = '\0';
    record_sample_rate = 0UL;
    data_bytes_written = 0UL;
    final_tail_written = false;
    finalization_has_error = false;
}

bool wav_record_engine_start(const char *directory_path,
                             uint32_t sample_rate)
{
    wav_record_engine_init();

    if (!sdcard_is_mounted())
    {
        wav_record_set_error("SD CARD ERROR");
        record_state = WAV_RECORD_ENGINE_ERROR;
        return false;
    }

    if (!wav_record_driver_prepare(sample_rate))
    {
        wav_record_set_error("BAD REC RATE");
        record_state = WAV_RECORD_ENGINE_ERROR;
        return false;
    }

    record_sample_rate = sample_rate;

    if (!wav_record_make_path(directory_path))
    {
        record_state = WAV_RECORD_ENGINE_ERROR;
        return false;
    }

    if (!sdcard_file_open_write(record_full_path))
    {
        wav_record_set_error("FILE CREATE ERR");
        record_state = WAV_RECORD_ENGINE_ERROR;
        return false;
    }

    if (!wav_record_write_header(0UL) || !sdcard_file_seek(44UL))
    {
        wav_record_close_with_error();
        return false;
    }

    if (!wav_record_driver_start())
    {
        wav_record_set_error("REC TIMER ERR");
        wav_record_close_with_error();
        return false;
    }

    record_state = WAV_RECORD_ENGINE_RECORDING;
    return true;
}

void wav_record_engine_request_stop(void)
{
    if (record_state != WAV_RECORD_ENGINE_RECORDING)
    {
        return;
    }

    wav_record_driver_stop();
    record_state = WAV_RECORD_ENGINE_FINALIZING;
}

void wav_record_engine_service(void)
{
    wav_record_driver_state_t driver_state;

    if (record_state == WAV_RECORD_ENGINE_RECORDING)
    {
        driver_state = wav_record_driver_get_state();

        if (driver_state == WAV_RECORD_DRIVER_OVERRUN)
        {
            wav_record_set_error("REC OVERFLOW");
            finalization_has_error = true;
            wav_record_driver_stop();
            record_state = WAV_RECORD_ENGINE_FINALIZING;
        }

        if (!wav_record_drain_one_block())
        {
            wav_record_close_with_error();
        }

        return;
    }

    if (record_state != WAV_RECORD_ENGINE_FINALIZING)
    {
        return;
    }

    if (!wav_record_drain_one_block())
    {
        wav_record_close_with_error();
        return;
    }

    if (record_sample_stream_available_bytes() != 0U)
    {
        return;
    }

    if (!wav_record_write_tail())
    {
        wav_record_close_with_error();
        return;
    }

    if (!wav_record_write_header(data_bytes_written) ||
        !sdcard_file_sync())
    {
        wav_record_close_with_error();
        return;
    }

    sdcard_file_close();

    record_state = finalization_has_error ?
        WAV_RECORD_ENGINE_ERROR : WAV_RECORD_ENGINE_FINISHED;
}

wav_record_engine_state_t wav_record_engine_get_state(void)
{
    return record_state;
}

const char *wav_record_engine_get_filename(void)
{
    return record_filename;
}

const char *wav_record_engine_get_full_path(void)
{
    return record_full_path;
}

const char *wav_record_engine_get_error_text(void)
{
    return record_error_text;
}

uint32_t wav_record_engine_get_sample_rate(void)
{
    return record_sample_rate;
}

uint32_t wav_record_engine_get_captured_samples(void)
{
    uint32_t queued =
        (uint32_t)record_sample_stream_available_bytes() * 8UL;
    uint32_t pending =
        (uint32_t)wav_record_driver_get_pending_sample_count();

    return data_bytes_written + queued + pending;
}

uint8_t wav_record_engine_get_buffer_fill_percent(void)
{
    return record_sample_stream_fill_percent();
}

uint8_t wav_record_engine_get_write_pin(void)
{
    return wav_record_driver_get_write_pin();
}
