#ifndef SD2CMT2_CMT_WORK_BUFFER_H
#define SD2CMT2_CMT_WORK_BUFFER_H

#include <stdint.h>

/*
    One foreground-only 512 B block shared by WAV PLAY and WAV RECORD.
    PLAY uses it for reading raw 8-bit WAV bytes from SD.
    RECORD uses it to expand 64 packed D15 bytes into one 512 B PCM sector.
    PLAY and RECORD are mutually exclusive, so this is safe and saves RAM.
*/
#define CMT_WORK_BUFFER_BYTES 512U

extern uint8_t cmt_work_buffer[CMT_WORK_BUFFER_BYTES];

#endif
