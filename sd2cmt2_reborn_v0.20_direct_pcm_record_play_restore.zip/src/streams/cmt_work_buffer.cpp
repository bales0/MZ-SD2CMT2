#include "cmt_work_buffer.h"

uint8_t cmt_work_buffer[CMT_WORK_BUFFER_BYTES];
