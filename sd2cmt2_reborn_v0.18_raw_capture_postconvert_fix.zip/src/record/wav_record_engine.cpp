#include "wav_record_engine.h"

#include <stdio.h>
#include <string.h>

#include "../drivers/sdcard.h"
#include "../drivers/wav_record_driver.h"
#include "../streams/record_sample_stream.h"

#define WAV_RECORD_PATH_MAX 160U
#define WAV_RECORD_FILENAME_MAX 16U

/*
    Capture format is packed 1-bit samples in RECnnnn.TMP. The capture stage
    therefore writes only 5512.5 B/s at 44.1 kHz, rather than 44100 B/s.
    Exact PCM conversion happens after the timer has stopped.
*/
#define WAV_RECORD_RAW_WRITE_BLOCK_BYTES 512U
#define WAV_RECORD_CONVERT_RAW_BLOCK_BYTES 64U
#define WAV_RECORD_PCM_BLOCK_BYTES 512U

/*
    WAV data starts at 512, so normal 512-byte PCM conversion writes are
    sector aligned. 36 + 8 + 460 = 504; data chunk header is at 504.
*/
#define WAV_RECORD_HEADER_BYTES 512U
#define WAV_RECORD_JUNK_PAYLOAD_BYTES 460U

/* 1 MiB raw capture capacity = about 190 s at 44.1 kHz. */
#define WAV_RECORD_RAW_PREALLOCATE_BYTES (1024UL * 1024UL)

static wav_record_engine_state_t record_state = WAV_RECORD_ENGINE_STOPPED;

static char record_full_path[WAV_RECORD_PATH_MAX];
static char record_temp_path[WAV_RECORD_PATH_MAX];
static char record_filename[WAV_RECORD_FILENAME_MAX];
static char record_error_text[17];

static uint32_t record_sample_rate = 0UL;
static uint32_t raw_bytes_written = 0UL;
static uint32_t pcm_bytes_written = 0UL;

static uint8_t raw_block[WAV_RECORD_RAW_WRITE_BLOCK_BYTES];
static uint8_t pcm_block[WAV_RECORD_PCM_BLOCK_BYTES];

static bool record_preallocated = false;
static bool raw_capture_closed = false;
static bool conversion_open = false;
static bool final_tail_taken = false;
static uint8_t final_tail_byte = 0U;
static uint8_t final_tail_bits = 0U;

static void wav_record_set_error(const char *text)
{
    if (text == NULL)
    {
        record_error_text[0] = '\0';
        return;
    }

    strncpy(record_error_text, text, sizeof(record_error_text) - 1U);
    record_error_text[sizeof(record_error_text) - 1U] = '\0';
}

static void wav_record_put_le16(uint8_t *target, uint16_t value)
{
    target[0] = (uint8_t)(value & 0xFFU);
    target[1] = (uint8_t)((value >> 8) & 0xFFU);
}

static void wav_record_put_le32(uint8_t *target, uint32_t value)
{
    target[0] = (uint8_t)(value & 0xFFUL);
    target[1] = (uint8_t)((value >> 8) & 0xFFUL);
    target[2] = (uint8_t)((value >> 16) & 0xFFUL);
    target[3] = (uint8_t)((value >> 24) & 0xFFUL);
}

static uint32_t wav_record_total_pcm_bytes(void)
{
    return (raw_bytes_written * 8UL) + (uint32_t)final_tail_bits;
}

static bool wav_record_write_conversion_header(uint32_t data_size)
{
    uint32_t riff_size;

    if (data_size > (0xFFFFFFFFUL - (WAV_RECORD_HEADER_BYTES - 8UL)))
    {
        wav_record_set_error("FILE TOO BIG");
        return false;
    }

    riff_size = data_size + (WAV_RECORD_HEADER_BYTES - 8UL);

    memset(pcm_block, 0, sizeof(pcm_block));
    memcpy(pcm_block + 0U, "RIFF", 4U);
    wav_record_put_le32(pcm_block + 4U, riff_size);
    memcpy(pcm_block + 8U, "WAVE", 4U);

    memcpy(pcm_block + 12U, "fmt ", 4U);
    wav_record_put_le32(pcm_block + 16U, 16UL);
    wav_record_put_le16(pcm_block + 20U, 1U);
    wav_record_put_le16(pcm_block + 22U, 1U);
    wav_record_put_le32(pcm_block + 24U, record_sample_rate);
    wav_record_put_le32(pcm_block + 28U, record_sample_rate);
    wav_record_put_le16(pcm_block + 32U, 1U);
    wav_record_put_le16(pcm_block + 34U, 8U);

    memcpy(pcm_block + 36U, "JUNK", 4U);
    wav_record_put_le32(pcm_block + 40U, WAV_RECORD_JUNK_PAYLOAD_BYTES);
    memcpy(pcm_block + 504U, "data", 4U);
    wav_record_put_le32(pcm_block + 508U, data_size);

    if (sdcard_convert_write(pcm_block, sizeof(pcm_block)) !=
        (int16_t)sizeof(pcm_block))
    {
        wav_record_set_error("WAV HEADER ERR");
        return false;
    }

    return true;
}

static bool wav_record_make_paths(const char *directory_path)
{
    if ((directory_path == NULL) || (directory_path[0] == '\0'))
    {
        wav_record_set_error("BAD DIRECTORY");
        return false;
    }

    for (uint16_t index = 1U; index <= 9999U; index++)
    {
        int wav_length;
        int tmp_length;

        if (strcmp(directory_path, "/") == 0)
        {
            wav_length = snprintf(record_full_path, sizeof(record_full_path),
                                  "/REC%04u.WAV", (unsigned int)index);
            tmp_length = snprintf(record_temp_path, sizeof(record_temp_path),
                                  "/REC%04u.TMP", (unsigned int)index);
        }
        else
        {
            wav_length = snprintf(record_full_path, sizeof(record_full_path),
                                  "%s/REC%04u.WAV", directory_path,
                                  (unsigned int)index);
            tmp_length = snprintf(record_temp_path, sizeof(record_temp_path),
                                  "%s/REC%04u.TMP", directory_path,
                                  (unsigned int)index);
        }

        if ((wav_length <= 0) || (tmp_length <= 0) ||
            ((size_t)wav_length >= sizeof(record_full_path)) ||
            ((size_t)tmp_length >= sizeof(record_temp_path)))
        {
            wav_record_set_error("PATH TOO LONG");
            return false;
        }

        if (!sdcard_file_exists(record_full_path) &&
            !sdcard_file_exists(record_temp_path))
        {
            snprintf(record_filename, sizeof(record_filename),
                     "REC%04u.WAV", (unsigned int)index);
            return true;
        }
    }

    wav_record_set_error("REC NAMES FULL");
    return false;
}

static uint16_t wav_record_expand_to_pcm(const uint8_t *packed,
                                         uint16_t byte_count,
                                         uint8_t valid_last_bits)
{
    uint16_t output_count = 0U;

    for (uint16_t byte_index = 0U; byte_index < byte_count; byte_index++)
    {
        uint8_t bits = 8U;

        if ((byte_index == (uint16_t)(byte_count - 1U)) &&
            (valid_last_bits != 0U) && (valid_last_bits < 8U))
        {
            bits = valid_last_bits;
        }

        for (uint8_t bit = 0U; bit < bits; bit++)
        {
            pcm_block[output_count++] =
                (packed[byte_index] & (uint8_t)(1U << bit)) ? 235U : 20U;
        }
    }

    return output_count;
}

/*
    Drain full 512-byte raw sectors while Timer1 is running. This writes only
    1/8 of the eventual WAV bandwidth and is the critical 44.1 kHz fix.
*/
static bool wav_record_drain_raw(bool allow_partial)
{
    uint16_t available = record_sample_stream_available_bytes();
    uint16_t request;
    uint16_t received;

    if (available == 0U)
    {
        return true;
    }

    if (!allow_partial && (available < WAV_RECORD_RAW_WRITE_BLOCK_BYTES))
    {
        return true;
    }

    request = allow_partial ? available : WAV_RECORD_RAW_WRITE_BLOCK_BYTES;
    if (request > WAV_RECORD_RAW_WRITE_BLOCK_BYTES)
    {
        request = WAV_RECORD_RAW_WRITE_BLOCK_BYTES;
    }

    received = record_sample_stream_pop_bytes(raw_block, request);
    if (received == 0U)
    {
        return true;
    }

    if (!allow_partial && (received != WAV_RECORD_RAW_WRITE_BLOCK_BYTES))
    {
        wav_record_set_error("REC FIFO RACE");
        return false;
    }

    if (sdcard_file_write(raw_block, received) != (int16_t)received)
    {
        wav_record_set_error("RAW WRITE ERR");
        return false;
    }

    raw_bytes_written += (uint32_t)received;
    return true;
}

static bool wav_record_drain_full_sectors(void)
{
    while (record_sample_stream_available_bytes() >=
           WAV_RECORD_RAW_WRITE_BLOCK_BYTES)
    {
        if (!wav_record_drain_raw(false))
        {
            return false;
        }
    }

    return true;
}

static bool wav_record_drain_all_raw(void)
{
    while (record_sample_stream_available_bytes() != 0U)
    {
        if (!wav_record_drain_raw(true))
        {
            return false;
        }
    }

    return true;
}

static bool wav_record_take_tail_once(void)
{
    if (final_tail_taken)
    {
        return true;
    }

    final_tail_taken = true;
    final_tail_byte = 0U;
    final_tail_bits = 0U;

    /* No partial byte is normal when STOP follows an exact 8-sample boundary. */
    (void)wav_record_driver_take_tail(&final_tail_byte, &final_tail_bits);
    return true;
}

static void wav_record_fail_and_close(const char *text)
{
    /*
        Most callers pass a literal. A few pass record_error_text after a
        lower-layer routine already supplied the exact reason; do not copy a
        C string onto itself in that case.
    */
    if ((text != NULL) && (text != record_error_text))
    {
        wav_record_set_error(text);
    }

    wav_record_driver_stop();
    sdcard_file_close();
    sdcard_convert_close();
    record_state = WAV_RECORD_ENGINE_ERROR;
}

static bool wav_record_finish_raw_capture(void)
{
    if (raw_capture_closed)
    {
        return true;
    }

    if (!wav_record_drain_all_raw())
    {
        return false;
    }

    if (!wav_record_take_tail_once())
    {
        wav_record_set_error("TAIL ERROR");
        return false;
    }

    if (record_preallocated && !sdcard_file_truncate(raw_bytes_written))
    {
        wav_record_set_error("TMP TRUNC ERR");
        return false;
    }

    if (!sdcard_file_sync())
    {
        wav_record_set_error("TMP SYNC ERR");
        return false;
    }

    sdcard_file_close();
    raw_capture_closed = true;
    return true;
}

static bool wav_record_start_conversion(void)
{
    if (conversion_open)
    {
        return true;
    }

    if (!sdcard_convert_open(record_temp_path, record_full_path))
    {
        wav_record_set_error("CONVERT OPEN");
        return false;
    }

    if (!wav_record_write_conversion_header(wav_record_total_pcm_bytes()))
    {
        return false;
    }

    conversion_open = true;
    return true;
}

/* One 64B raw -> 512B PCM conversion unit per service call. */
static bool wav_record_convert_one_block(bool *finished)
{
    int16_t received;
    uint16_t pcm_count;

    if (finished == NULL)
    {
        return false;
    }

    *finished = false;
    received = sdcard_convert_read(raw_block,
                                   WAV_RECORD_CONVERT_RAW_BLOCK_BYTES);

    if (received < 0)
    {
        wav_record_set_error("TMP READ ERR");
        return false;
    }

    if (received > 0)
    {
        pcm_count = wav_record_expand_to_pcm(raw_block,
                                             (uint16_t)received,
                                             8U);
        if (sdcard_convert_write(pcm_block, pcm_count) !=
            (int16_t)pcm_count)
        {
            wav_record_set_error("WAV WRITE ERR");
            return false;
        }

        pcm_bytes_written += (uint32_t)pcm_count;
        return true;
    }

    if (final_tail_bits != 0U)
    {
        raw_block[0] = final_tail_byte;
        pcm_count = wav_record_expand_to_pcm(raw_block, 1U,
                                             final_tail_bits);
        if (sdcard_convert_write(pcm_block, pcm_count) !=
            (int16_t)pcm_count)
        {
            wav_record_set_error("WAV TAIL ERR");
            return false;
        }
        pcm_bytes_written += (uint32_t)pcm_count;
        final_tail_bits = 0U;
        return true;
    }

    *finished = true;
    return true;
}

void wav_record_engine_init(void)
{
    wav_record_driver_init();

    record_state = WAV_RECORD_ENGINE_STOPPED;
    record_full_path[0] = '\0';
    record_temp_path[0] = '\0';
    record_filename[0] = '\0';
    record_error_text[0] = '\0';
    record_sample_rate = 0UL;
    raw_bytes_written = 0UL;
    pcm_bytes_written = 0UL;
    record_preallocated = false;
    raw_capture_closed = false;
    conversion_open = false;
    final_tail_taken = false;
    final_tail_byte = 0U;
    final_tail_bits = 0U;
}

bool wav_record_engine_start(const char *directory_path,
                             uint32_t sample_rate)
{
    wav_record_engine_init();

    if (!sdcard_is_mounted())
    {
        wav_record_set_error("SD CARD ERROR");
        record_state = WAV_RECORD_ENGINE_ERROR;
        return false;
    }

    if (!wav_record_driver_prepare(sample_rate))
    {
        wav_record_set_error("BAD REC RATE");
        record_state = WAV_RECORD_ENGINE_ERROR;
        return false;
    }

    record_sample_rate = sample_rate;

    if (!wav_record_make_paths(directory_path))
    {
        record_state = WAV_RECORD_ENGINE_ERROR;
        return false;
    }

    if (!sdcard_file_open_write(record_temp_path))
    {
        wav_record_set_error("TMP CREATE ERR");
        record_state = WAV_RECORD_ENGINE_ERROR;
        return false;
    }

    /* Optional contiguous reservation happens before Timer1 starts. */
    record_preallocated = sdcard_file_preallocate(
        WAV_RECORD_RAW_PREALLOCATE_BYTES
    );

    if (!sdcard_file_seek(0UL))
    {
        wav_record_fail_and_close("TMP SEEK ERR");
        return false;
    }

    if (!wav_record_driver_start())
    {
        wav_record_fail_and_close("REC TIMER ERR");
        return false;
    }

    record_state = WAV_RECORD_ENGINE_RECORDING;
    return true;
}

void wav_record_engine_request_stop(void)
{
    if (record_state != WAV_RECORD_ENGINE_RECORDING)
    {
        return;
    }

    wav_record_driver_stop();
    record_state = WAV_RECORD_ENGINE_FINALIZING;
}

void wav_record_engine_service(void)
{
    wav_record_driver_state_t driver_state;
    bool conversion_finished;

    if (record_state == WAV_RECORD_ENGINE_RECORDING)
    {
        driver_state = wav_record_driver_get_state();

        if (driver_state == WAV_RECORD_DRIVER_OVERRUN)
        {
            wav_record_fail_and_close("REC OVERFLOW");
            return;
        }

        if (!wav_record_drain_full_sectors())
        {
            wav_record_fail_and_close(record_error_text);
        }

        return;
    }

    if (record_state != WAV_RECORD_ENGINE_FINALIZING)
    {
        return;
    }

    if (!raw_capture_closed)
    {
        if (!wav_record_finish_raw_capture())
        {
            wav_record_fail_and_close(record_error_text);
            return;
        }
    }

    if (!wav_record_start_conversion())
    {
        wav_record_fail_and_close(record_error_text);
        return;
    }

    /* Conversion has no realtime deadline. Bound it to four sectors/service. */
    for (uint8_t block = 0U; block < 4U; block++)
    {
        if (!wav_record_convert_one_block(&conversion_finished))
        {
            wav_record_fail_and_close(record_error_text);
            return;
        }

        if (conversion_finished)
        {
            if (pcm_bytes_written != wav_record_total_pcm_bytes())
            {
                wav_record_fail_and_close("CONVERT SIZE");
                return;
            }

            if (!sdcard_convert_close())
            {
                wav_record_fail_and_close("CONVERT CLOSE");
                return;
            }

            conversion_open = false;

            if (!sdcard_file_remove(record_temp_path))
            {
                wav_record_fail_and_close("TMP REMOVE ERR");
                return;
            }

            record_state = WAV_RECORD_ENGINE_FINISHED;
            return;
        }
    }
}

wav_record_engine_state_t wav_record_engine_get_state(void)
{
    return record_state;
}

const char *wav_record_engine_get_filename(void)
{
    return record_filename;
}

const char *wav_record_engine_get_full_path(void)
{
    return record_full_path;
}

const char *wav_record_engine_get_error_text(void)
{
    return record_error_text;
}

uint32_t wav_record_engine_get_sample_rate(void)
{
    return record_sample_rate;
}

uint32_t wav_record_engine_get_captured_samples(void)
{
    uint32_t queued =
        (uint32_t)record_sample_stream_available_bytes() * 8UL;
    uint32_t pending =
        (uint32_t)wav_record_driver_get_pending_sample_count();

    return (raw_bytes_written * 8UL) + queued + pending;
}

uint8_t wav_record_engine_get_buffer_fill_percent(void)
{
    return record_sample_stream_fill_percent();
}

uint8_t wav_record_engine_get_write_pin(void)
{
    return wav_record_driver_get_write_pin();
}
