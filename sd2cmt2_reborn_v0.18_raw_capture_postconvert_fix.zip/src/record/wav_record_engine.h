#ifndef SD2CMT2_WAV_RECORD_ENGINE_H
#define SD2CMT2_WAV_RECORD_ENGINE_H

#include <stdbool.h>
#include <stdint.h>

typedef enum
{
    WAV_RECORD_ENGINE_STOPPED = 0,
    WAV_RECORD_ENGINE_RECORDING,
    WAV_RECORD_ENGINE_FINALIZING,
    WAV_RECORD_ENGINE_FINISHED,
    WAV_RECORD_ENGINE_ERROR

} wav_record_engine_state_t;

void wav_record_engine_init(void);

/*
    Starts REC0001.WAV ... REC9999.WAV in directory_path.

    Capture itself stores one bit per input sample into a temporary .TMP file.
    After STOP, foreground code expands it exactly to WAV PCM values 20/235.
    This keeps the realtime part at only 1/8 of the final WAV write rate.
*/
bool wav_record_engine_start(const char *directory_path,
                             uint32_t sample_rate);

/* Stop the sample clock; remaining data is flushed and converted to WAV. */
void wav_record_engine_request_stop(void);

/* Foreground only. Call as frequently as possible while RECORD is active. */
void wav_record_engine_service(void);

wav_record_engine_state_t wav_record_engine_get_state(void);

const char *wav_record_engine_get_filename(void);
const char *wav_record_engine_get_full_path(void);
const char *wav_record_engine_get_error_text(void);

uint32_t wav_record_engine_get_sample_rate(void);
uint32_t wav_record_engine_get_captured_samples(void);
uint8_t wav_record_engine_get_buffer_fill_percent(void);
uint8_t wav_record_engine_get_write_pin(void);

#endif
