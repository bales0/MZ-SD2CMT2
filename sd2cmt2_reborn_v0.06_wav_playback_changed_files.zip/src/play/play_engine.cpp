#include <Arduino.h>
#include <string.h>

#include "play_engine.h"
#include "../drivers/wav_playback_driver.h"
#include "../streams/wav_sample_stream.h"

#define PLAY_ENGINE_PATH_MAX 160
#define WAV_STREAM_LOW_WATERMARK 768U

static char prepared_full_path[PLAY_ENGINE_PATH_MAX];
static file_format_t prepared_format = FILE_FORMAT_UNKNOWN;
static menu_play_mode_t prepared_play_mode = MENU_PLAY_MODE_NORMAL;
static bool prepared_invert_signal = false;
static play_engine_state_t engine_state = PLAY_ENGINE_STATE_STOPPED;

static bool play_engine_wav_pop_sample_from_isr(uint8_t *level)
{
    return wav_sample_stream_pop_from_isr(level);
}

static bool play_engine_wav_finished_from_isr(void)
{
    return wav_sample_stream_finished_from_isr();
}

static bool play_engine_prepare_wav(void)
{
    wav_sample_stream_config_t stream_config;
    const wav_reader_info_t *info;

    stream_config.low_threshold = 100;
    stream_config.high_threshold = 155;
    stream_config.invert_signal = prepared_invert_signal;

    if (!wav_sample_stream_open(prepared_full_path, &stream_config))
    {
        return false;
    }

    info = wav_sample_stream_info();

    if ((info == NULL) ||
        !wav_playback_driver_prepare(info->sample_rate,
                                     play_engine_wav_pop_sample_from_isr,
                                     play_engine_wav_finished_from_isr))
    {
        wav_sample_stream_close();
        return false;
    }

    return true;
}

void play_engine_init(void)
{
    prepared_full_path[0] = '\0';
    prepared_format = FILE_FORMAT_UNKNOWN;
    prepared_play_mode = MENU_PLAY_MODE_NORMAL;
    prepared_invert_signal = false;
    engine_state = PLAY_ENGINE_STATE_STOPPED;

    wav_playback_driver_init();
}

bool play_engine_prepare(const play_engine_config_t *config)
{
    play_engine_stop();

    if ((config == NULL) || (config->full_path == NULL) ||
        (config->format == FILE_FORMAT_UNKNOWN))
    {
        engine_state = PLAY_ENGINE_STATE_ERROR;
        return false;
    }

    strncpy(prepared_full_path, config->full_path, sizeof(prepared_full_path) - 1);
    prepared_full_path[sizeof(prepared_full_path) - 1] = '\0';
    prepared_format = config->format;
    prepared_play_mode = config->play_mode;
    prepared_invert_signal = config->invert_signal;

    if ((prepared_format == FILE_FORMAT_WAV) && !play_engine_prepare_wav())
    {
        engine_state = PLAY_ENGINE_STATE_ERROR;
        return false;
    }

    /* Other supported tape formats remain in their existing stub state. */
    engine_state = PLAY_ENGINE_STATE_READY;
    return true;
}

bool play_engine_start(void)
{
    if (engine_state != PLAY_ENGINE_STATE_READY)
    {
        return false;
    }

    if ((prepared_format == FILE_FORMAT_WAV) && !wav_playback_driver_start())
    {
        engine_state = PLAY_ENGINE_STATE_ERROR;
        return false;
    }

    engine_state = PLAY_ENGINE_STATE_RUNNING;
    return true;
}

bool play_engine_pause(void)
{
    if (engine_state != PLAY_ENGINE_STATE_RUNNING)
    {
        return false;
    }

    if ((prepared_format == FILE_FORMAT_WAV) && !wav_playback_driver_pause())
    {
        engine_state = PLAY_ENGINE_STATE_ERROR;
        return false;
    }

    engine_state = PLAY_ENGINE_STATE_PAUSED;
    return true;
}

bool play_engine_resume(void)
{
    if (engine_state != PLAY_ENGINE_STATE_PAUSED)
    {
        return false;
    }

    if ((prepared_format == FILE_FORMAT_WAV) && !wav_playback_driver_resume())
    {
        engine_state = PLAY_ENGINE_STATE_ERROR;
        return false;
    }

    engine_state = PLAY_ENGINE_STATE_RUNNING;
    return true;
}

void play_engine_stop(void)
{
    wav_playback_driver_stop();
    wav_sample_stream_close();

    engine_state = PLAY_ENGINE_STATE_STOPPED;
}

void play_engine_service(void)
{
    if (engine_state != PLAY_ENGINE_STATE_RUNNING)
    {
        return;
    }

    if (prepared_format != FILE_FORMAT_WAV)
    {
        return;
    }

    switch (wav_playback_driver_get_state())
    {
        case WAV_PLAYBACK_DRIVER_RUNNING:
            /* One 64-byte SD block per foreground call avoids long blocking. */
            if ((wav_sample_stream_available() < WAV_STREAM_LOW_WATERMARK) &&
                !wav_sample_stream_source_finished())
            {
                if (!wav_sample_stream_refill_block())
                {
                    wav_playback_driver_stop();
                    engine_state = PLAY_ENGINE_STATE_ERROR;
                }
            }
            break;

        case WAV_PLAYBACK_DRIVER_FINISHED:
            /* Re-open and prefill so SELECT can immediately replay the WAV. */
            wav_playback_driver_stop();

            if (play_engine_prepare_wav())
            {
                engine_state = PLAY_ENGINE_STATE_READY;
            }
            else
            {
                engine_state = PLAY_ENGINE_STATE_ERROR;
            }
            break;

        case WAV_PLAYBACK_DRIVER_UNDERRUN:
        case WAV_PLAYBACK_DRIVER_BAD_RATE:
        case WAV_PLAYBACK_DRIVER_BAD_ARGUMENT:
            engine_state = PLAY_ENGINE_STATE_ERROR;
            break;

        case WAV_PLAYBACK_DRIVER_READY:
        case WAV_PLAYBACK_DRIVER_PAUSED:
        case WAV_PLAYBACK_DRIVER_STOPPED:
        default:
            break;
    }
}

play_engine_state_t play_engine_get_state(void)
{
    return engine_state;
}
