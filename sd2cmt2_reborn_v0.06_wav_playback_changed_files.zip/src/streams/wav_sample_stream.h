#ifndef SD2CMT2_WAV_SAMPLE_STREAM_H
#define SD2CMT2_WAV_SAMPLE_STREAM_H

#include <stdbool.h>
#include <stdint.h>

#include "../formats/wav_reader.h"

/*
    Prepared logical READ levels (0/1), not original PCM values.

    1024 samples provide:
    - 46.4 ms at 22050 Hz
    - 23.2 ms at 44100 Hz
    - 21.3 ms at 48000 Hz

    It must stay a power of two because indexing uses a mask.
*/
#define WAV_SAMPLE_STREAM_BUFFER_SIZE 1024U
#define WAV_SAMPLE_STREAM_REFILL_BLOCK 64U

typedef struct
{
    uint8_t low_threshold;
    uint8_t high_threshold;
    bool invert_signal;

} wav_sample_stream_config_t;

/*
    Opens a WAV file and pre-fills the whole prepared-level ring buffer.
    Threshold and hysteresis execute only in foreground code.
*/
bool wav_sample_stream_open(const char *path,
                            const wav_sample_stream_config_t *config);

void wav_sample_stream_close(void);

/*
    Read and prepare at most WAV_SAMPLE_STREAM_REFILL_BLOCK samples.
    Call regularly from foreground code while playback is running.
    Never call from a timer ISR.
*/
bool wav_sample_stream_refill_block(void);

/* Fill all currently available free space. Use only before timer start. */
bool wav_sample_stream_prefill(void);

/* Safe for normal foreground code. */
bool wav_sample_stream_pop(uint8_t *level);

/*
    Intended only for the fixed-rate WAV timer ISR. It just dequeues a
    precomputed 0/1 value: no SD, no parsing, no threshold, no hysteresis.
*/
bool wav_sample_stream_pop_from_isr(uint8_t *level);

uint16_t wav_sample_stream_available(void);

bool wav_sample_stream_source_finished(void);

bool wav_sample_stream_finished(void);

/* Only for the Timer ISR callback; no atomic block is entered. */
bool wav_sample_stream_finished_from_isr(void);

const wav_reader_info_t *wav_sample_stream_info(void);

wav_reader_status_t wav_sample_stream_last_status(void);

#endif
