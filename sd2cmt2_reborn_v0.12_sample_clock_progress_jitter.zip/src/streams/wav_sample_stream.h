#ifndef SD2CMT2_WAV_SAMPLE_STREAM_H
#define SD2CMT2_WAV_SAMPLE_STREAM_H

#include <stdbool.h>
#include <stdint.h>

#include "../formats/wav_reader.h"

/*
    Prepared binary samples, packed one bit per WAV sample.

    2048 SRAM bytes hold 16383 samples:
    - 742.8 ms at 22050 Hz
    - 371.5 ms at 44100 Hz
    - 341.3 ms at 48000 Hz

    Playback is sample-for-sample: one queued bit corresponds to exactly one
    source WAV sample period. There is no run-length conversion.
*/
#define WAV_SAMPLE_STREAM_BUFFER_BYTES 2048U
#define WAV_SAMPLE_STREAM_CAPACITY_SAMPLES \
    ((WAV_SAMPLE_STREAM_BUFFER_BYTES * 8U) - 1U)

#define WAV_SAMPLE_STREAM_REFILL_BLOCK 512U

typedef struct
{
    uint8_t low_threshold;
    uint8_t high_threshold;
    bool invert_signal;

} wav_sample_stream_config_t;

bool wav_sample_stream_open(const char *path,
                            const wav_sample_stream_config_t *config);

void wav_sample_stream_close(void);

/*
    Foreground only. Reads up to WAV_SAMPLE_STREAM_REFILL_BLOCK WAV bytes,
    applies hysteresis, and publishes prepared 0/1 sample bits.
*/
bool wav_sample_stream_refill_block(void);

/* Fill all currently free storage before Timer1 starts. */
bool wav_sample_stream_prefill(void);

/* Foreground dequeue, used by unit tests and diagnostics. */
bool wav_sample_stream_pop(uint8_t *level);

/*
    Timer ISR dequeue. It only loads one packed already-prepared bit and
    advances the single-consumer sequence counter.
*/
bool wav_sample_stream_pop_from_isr(uint8_t *level);

uint16_t wav_sample_stream_available(void);

bool wav_sample_stream_source_finished(void);

bool wav_sample_stream_finished(void);

/* ISR-safe normal EOF predicate. */
bool wav_sample_stream_finished_from_isr(void);

const wav_reader_info_t *wav_sample_stream_info(void);

wav_reader_status_t wav_sample_stream_last_status(void);

#endif
