#include "wav_sample_stream.h"

#include <stddef.h>

#include <Arduino.h>
#include <util/atomic.h>

#if ((WAV_SAMPLE_STREAM_BUFFER_BYTES & (WAV_SAMPLE_STREAM_BUFFER_BYTES - 1U)) != 0)
#error "WAV_SAMPLE_STREAM_BUFFER_BYTES must be a power of two"
#endif

#if (WAV_SAMPLE_STREAM_CAPACITY_SAMPLES > 32767U)
#error "Packed stream capacity must be <= 32767 samples"
#endif

#define WAV_SAMPLE_STREAM_BIT_MASK \
    ((WAV_SAMPLE_STREAM_BUFFER_BYTES * 8U) - 1U)

static uint8_t wav_level_bits[WAV_SAMPLE_STREAM_BUFFER_BYTES];
static uint8_t wav_raw_buffer[WAV_SAMPLE_STREAM_REFILL_BLOCK];

/*
    Sequence counters count logical samples, not bytes. The producer publishes
    write_sequence only after all bit values have been written. The ISR only
    advances read_sequence after consuming one previously published bit.
*/
static volatile uint16_t read_sequence = 0;
static volatile uint16_t write_sequence = 0;

static bool input_level = false;
static volatile bool source_finished = false;

static wav_sample_stream_config_t stream_config =
{
    100,
    155,
    false
};

static wav_reader_info_t stream_info;
static wav_reader_status_t stream_status = WAV_READER_STATUS_BAD_ARGUMENT;

static uint16_t wav_sample_stream_available_snapshot(void)
{
    uint16_t read_snapshot;
    uint16_t write_snapshot;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        read_snapshot = read_sequence;
        write_snapshot = write_sequence;
    }

    return (uint16_t)(write_snapshot - read_snapshot);
}

static uint8_t wav_sample_stream_decode(uint8_t sample)
{
    /*
        The center of the hysteresis window preserves the previous level.
        No undefined state and no artificial transition are introduced.
    */
    if (!input_level)
    {
        if (sample >= stream_config.high_threshold)
        {
            input_level = true;
        }
    }
    else
    {
        if (sample <= stream_config.low_threshold)
        {
            input_level = false;
        }
    }

    return (uint8_t)((input_level ^ stream_config.invert_signal) ? 1U : 0U);
}

static void wav_sample_stream_store_bit(uint16_t sequence, uint8_t level)
{
    uint16_t bit_position = (uint16_t)(sequence & WAV_SAMPLE_STREAM_BIT_MASK);
    uint16_t byte_index = (uint16_t)(bit_position >> 3);
    uint8_t bit_mask = (uint8_t)(1U << (bit_position & 7U));

    if (level)
    {
        wav_level_bits[byte_index] |= bit_mask;
    }
    else
    {
        wav_level_bits[byte_index] &= (uint8_t)~bit_mask;
    }
}

static uint8_t wav_sample_stream_load_bit(uint16_t sequence)
{
    uint16_t bit_position = (uint16_t)(sequence & WAV_SAMPLE_STREAM_BIT_MASK);
    uint16_t byte_index = (uint16_t)(bit_position >> 3);
    uint8_t shift = (uint8_t)(bit_position & 7U);

    return (uint8_t)((wav_level_bits[byte_index] >> shift) & 1U);
}

static bool wav_sample_stream_pop_internal(uint8_t *level)
{
    uint16_t read_local;

    if (level == NULL)
    {
        return false;
    }

    read_local = read_sequence;

    if (read_local == write_sequence)
    {
        return false;
    }

    *level = wav_sample_stream_load_bit(read_local);
    read_sequence = (uint16_t)(read_local + 1U);

    return true;
}

bool wav_sample_stream_open(const char *path,
                            const wav_sample_stream_config_t *config)
{
    if ((path == NULL) ||
        (config == NULL) ||
        (config->low_threshold >= config->high_threshold))
    {
        stream_status = WAV_READER_STATUS_BAD_ARGUMENT;
        return false;
    }

    wav_sample_stream_close();

    stream_config = *config;
    input_level = false;
    source_finished = false;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        read_sequence = 0;
        write_sequence = 0;
    }

    if (!wav_reader_open(path, &stream_info))
    {
        stream_status = wav_reader_last_status();
        return false;
    }

    stream_status = WAV_READER_STATUS_OK;

    return wav_sample_stream_prefill();
}

void wav_sample_stream_close(void)
{
    wav_reader_close();

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        read_sequence = 0;
        write_sequence = 0;
    }

    input_level = false;
    source_finished = true;
}

bool wav_sample_stream_refill_block(void)
{
    uint16_t read_snapshot;
    uint16_t write_snapshot;
    uint16_t used;
    uint16_t free_space;
    uint16_t request;
    uint16_t write_local;
    int16_t received;

    if (source_finished)
    {
        return true;
    }

    if (!wav_reader_is_open())
    {
        stream_status = wav_reader_last_status();
        return false;
    }

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        read_snapshot = read_sequence;
        write_snapshot = write_sequence;
    }

    used = (uint16_t)(write_snapshot - read_snapshot);

    if (used > WAV_SAMPLE_STREAM_CAPACITY_SAMPLES)
    {
        stream_status = WAV_READER_STATUS_IO_ERROR;
        return false;
    }

    free_space = (uint16_t)(WAV_SAMPLE_STREAM_CAPACITY_SAMPLES - used);

    if (free_space == 0)
    {
        return true;
    }

    request = free_space;

    if (request > WAV_SAMPLE_STREAM_REFILL_BLOCK)
    {
        request = WAV_SAMPLE_STREAM_REFILL_BLOCK;
    }

    received = wav_reader_read_samples(wav_raw_buffer, request);

    if (received < 0)
    {
        stream_status = wav_reader_last_status();
        return false;
    }

    if (received == 0)
    {
        source_finished = true;
        return true;
    }

    write_local = write_snapshot;

    for (int16_t i = 0; i < received; i++)
    {
        wav_sample_stream_store_bit(
            write_local,
            wav_sample_stream_decode(wav_raw_buffer[i])
        );

        write_local = (uint16_t)(write_local + 1U);
    }

    /*
        Publish only after all converted bits are visible in SRAM. The atomic
        section is short; SdFat and conversion are never executed with IRQs
        disabled.
    */
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        write_sequence = write_local;
    }

    return true;
}

bool wav_sample_stream_prefill(void)
{
    while (!source_finished)
    {
        uint16_t before = wav_sample_stream_available_snapshot();

        if (!wav_sample_stream_refill_block())
        {
            return false;
        }

        if (wav_sample_stream_available_snapshot() == before)
        {
            break;
        }
    }

    return true;
}

bool wav_sample_stream_pop(uint8_t *level)
{
    bool result;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        result = wav_sample_stream_pop_internal(level);
    }

    return result;
}

bool wav_sample_stream_pop_from_isr(uint8_t *level)
{
    return wav_sample_stream_pop_internal(level);
}

uint16_t wav_sample_stream_available(void)
{
    return wav_sample_stream_available_snapshot();
}

bool wav_sample_stream_source_finished(void)
{
    return source_finished;
}

bool wav_sample_stream_finished(void)
{
    return source_finished && (wav_sample_stream_available_snapshot() == 0);
}

bool wav_sample_stream_finished_from_isr(void)
{
    return source_finished && (read_sequence == write_sequence);
}

const wav_reader_info_t *wav_sample_stream_info(void)
{
    return wav_reader_is_open() ? &stream_info : NULL;
}

wav_reader_status_t wav_sample_stream_last_status(void)
{
    return stream_status;
}
