#include "wav_playback_driver.h"

#include <stddef.h>

#include <Arduino.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/atomic.h>

#include "mzio.h"

#if !defined(TIMER1_COMPA_vect)
#error "WAV playback driver requires Timer1 compare A on Arduino Mega 2560"
#endif

/*
    One true fixed-rate sample clock:

    - Timer1 runs directly from the 16 MHz CPU clock.
    - 22050/44100/48000 Hz are produced by a fractional divider that alternates
      only between adjacent integer periods.
    - ISR starts by writing the already prefetched output level to READ.
    - SD, WAV parsing and threshold/hysteresis are strictly foreground work.
*/
static volatile uint8_t driver_state = WAV_PLAYBACK_DRIVER_STOPPED;

static wav_playback_pop_sample_fn pop_sample_callback = NULL;
static wav_playback_source_finished_fn source_finished_callback = NULL;

static volatile uint16_t timer_sample_rate = 0;
static volatile uint16_t timer_base_ticks = 0;
static volatile uint16_t timer_remainder_ticks = 0;
static volatile uint16_t timer_phase_ticks = 0;

static volatile uint8_t next_output_level = 0;
static volatile bool next_output_valid = false;

static volatile uint32_t played_samples = 0;

static volatile uint16_t min_latency_ticks = 0xFFFFU;
static volatile uint16_t max_latency_ticks = 0;

static inline void wav_playback_disable_timer_from_isr(void)
{
    TCCR1B = _BV(WGM12);
    TIMSK1 &= (uint8_t)~_BV(OCIE1A);
    TIFR1 = _BV(OCF1A);
}

static wav_playback_driver_state_t wav_playback_state_snapshot(void)
{
    uint8_t state;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        state = driver_state;
    }

    return (wav_playback_driver_state_t)state;
}

static bool wav_playback_fetch_next_sample(void)
{
    uint8_t level = 0;

    if ((pop_sample_callback == NULL) || !pop_sample_callback(&level))
    {
        next_output_valid = false;
        return false;
    }

    next_output_level = (uint8_t)(level & 1U);
    next_output_valid = true;
    return true;
}

/*
    Program one full sample interval. The numerator is represented as:
      F_CPU / rate = base + remainder / rate
    so no 32-bit division occurs inside the ISR.
*/
static inline void wav_playback_schedule_full_sample_period(void)
{
    uint16_t ticks = timer_base_ticks;
    uint16_t phase = timer_phase_ticks;
    uint16_t threshold = (uint16_t)(
        timer_sample_rate - timer_remainder_ticks
    );

    if (phase >= threshold)
    {
        phase = (uint16_t)(phase - threshold);
        ticks++;
    }
    else
    {
        phase = (uint16_t)(phase + timer_remainder_ticks);
    }

    timer_phase_ticks = phase;
    OCR1A = (uint16_t)(ticks - 1U);
}

/* OCR1A is valid before this enables Timer1 and its compare interrupt. */
static void wav_playback_enable_timer_from_foreground(void)
{
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        TCNT1 = 0;
        TIFR1 = _BV(OCF1A);
        driver_state = WAV_PLAYBACK_DRIVER_RUNNING;
        TIMSK1 |= _BV(OCIE1A);
        TCCR1B = _BV(WGM12) | _BV(CS10);
    }
}

static void wav_playback_set_finished_from_isr(void)
{
    wav_playback_disable_timer_from_isr();
    mz_read_set_from_isr(0);
    driver_state = WAV_PLAYBACK_DRIVER_FINISHED;
}

void wav_playback_driver_init(void)
{
    mzio_init();

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        TCCR1A = 0;
        TCCR1B = _BV(WGM12);
        TCNT1 = 0;
        OCR1A = 0xFFFFU;
        TIMSK1 &= (uint8_t)~_BV(OCIE1A);
        TIFR1 = _BV(OCF1A);
    }

    pop_sample_callback = NULL;
    source_finished_callback = NULL;

    timer_sample_rate = 0;
    timer_base_ticks = 0;
    timer_remainder_ticks = 0;
    timer_phase_ticks = 0;

    next_output_level = 0;
    next_output_valid = false;

    played_samples = 0;
    min_latency_ticks = 0xFFFFU;
    max_latency_ticks = 0;

    driver_state = WAV_PLAYBACK_DRIVER_STOPPED;
}

bool wav_playback_driver_prepare(uint32_t sample_rate,
                                 wav_playback_pop_sample_fn pop_sample,
                                 wav_playback_source_finished_fn source_finished)
{
    uint32_t base_ticks;
    uint32_t remainder_ticks;

    if ((sample_rate == 0UL) ||
        (sample_rate > 65535UL) ||
        (pop_sample == NULL) ||
        (source_finished == NULL))
    {
        driver_state = WAV_PLAYBACK_DRIVER_BAD_ARGUMENT;
        return false;
    }

    base_ticks = (uint32_t)F_CPU / sample_rate;
    remainder_ticks = (uint32_t)F_CPU % sample_rate;

    /*
        The supported WAV rates are much lower than F_CPU, so every sample
        interval fits within Timer1's 16-bit CTC period.
    */
    if ((base_ticks == 0UL) || (base_ticks > 65535UL))
    {
        driver_state = WAV_PLAYBACK_DRIVER_BAD_RATE;
        return false;
    }

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        TCCR1B = _BV(WGM12);
        TIMSK1 &= (uint8_t)~_BV(OCIE1A);
        TIFR1 = _BV(OCF1A);
        TCNT1 = 0;

        timer_sample_rate = (uint16_t)sample_rate;
        timer_base_ticks = (uint16_t)base_ticks;
        timer_remainder_ticks = (uint16_t)remainder_ticks;
        timer_phase_ticks = 0;

        next_output_level = 0;
        next_output_valid = false;

        played_samples = 0;
        min_latency_ticks = 0xFFFFU;
        max_latency_ticks = 0;

        pop_sample_callback = pop_sample;
        source_finished_callback = source_finished;
        driver_state = WAV_PLAYBACK_DRIVER_READY;
    }

    mz_read_set(false);
    return true;
}

bool wav_playback_driver_start(void)
{
    uint8_t first_level = 0;

    if (wav_playback_state_snapshot() != WAV_PLAYBACK_DRIVER_READY)
    {
        return false;
    }

    if ((pop_sample_callback == NULL) ||
        !pop_sample_callback(&first_level))
    {
        driver_state = source_finished_callback() ?
            WAV_PLAYBACK_DRIVER_FINISHED : WAV_PLAYBACK_DRIVER_UNDERRUN;
        return false;
    }

    /*
        Output sample zero immediately at t=0 and prefetch sample one.
        The ISR can therefore write its READ value first, before it touches
        the ring-buffer state.
    */
    mz_read_set_from_isr(first_level);
    played_samples = 1U;

    (void)wav_playback_fetch_next_sample();

    wav_playback_schedule_full_sample_period();
    wav_playback_enable_timer_from_foreground();

    return true;
}

bool wav_playback_driver_pause(void)
{
    if (wav_playback_state_snapshot() != WAV_PLAYBACK_DRIVER_RUNNING)
    {
        return false;
    }

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        TCCR1B = _BV(WGM12);
        TIMSK1 &= (uint8_t)~_BV(OCIE1A);
        TIFR1 = _BV(OCF1A);
        driver_state = WAV_PLAYBACK_DRIVER_PAUSED;
    }

    return true;
}

bool wav_playback_driver_resume(void)
{
    if (wav_playback_state_snapshot() != WAV_PLAYBACK_DRIVER_PAUSED)
    {
        return false;
    }

    /*
        A pause deliberately holds the current logical sample. Resume starts
        a fresh full sample period before the already-prefetched next sample.
        This keeps the post-resume waveform sample-aligned.
    */
    wav_playback_schedule_full_sample_period();
    wav_playback_enable_timer_from_foreground();
    return true;
}

void wav_playback_driver_stop(void)
{
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        TCCR1B = _BV(WGM12);
        TIMSK1 &= (uint8_t)~_BV(OCIE1A);
        TIFR1 = _BV(OCF1A);
        driver_state = WAV_PLAYBACK_DRIVER_STOPPED;
        next_output_valid = false;
        played_samples = 0;
    }

    mz_read_set(false);
    pop_sample_callback = NULL;
    source_finished_callback = NULL;
}

wav_playback_driver_state_t wav_playback_driver_get_state(void)
{
    return wav_playback_state_snapshot();
}

uint32_t wav_playback_driver_get_sample_rate(void)
{
    uint16_t sample_rate;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        sample_rate = timer_sample_rate;
    }

    return (uint32_t)sample_rate;
}

uint8_t wav_playback_driver_get_read_pin(void)
{
    return mzio_read_pin();
}

uint32_t wav_playback_driver_get_played_samples(void)
{
    uint32_t sample_count;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        sample_count = played_samples;
    }

    return sample_count;
}

uint16_t wav_playback_driver_get_jitter_ticks(void)
{
    uint16_t minimum;
    uint16_t maximum;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        minimum = min_latency_ticks;
        maximum = max_latency_ticks;
    }

    if (minimum == 0xFFFFU)
    {
        return 0;
    }

    return (uint16_t)(maximum - minimum);
}

ISR(TIMER1_COMPA_vect)
{
    uint16_t latency;

    if ((driver_state != WAV_PLAYBACK_DRIVER_RUNNING) ||
        (pop_sample_callback == NULL) ||
        (source_finished_callback == NULL))
    {
        wav_playback_disable_timer_from_isr();
        driver_state = WAV_PLAYBACK_DRIVER_BAD_ARGUMENT;
        return;
    }

    /*
        This direct port write is intentionally the first time-critical work
        in the ISR. It emits exactly one already prepared WAV sample level.
    */
    if (!next_output_valid)
    {
        if (source_finished_callback())
        {
            wav_playback_set_finished_from_isr();
        }
        else
        {
            wav_playback_disable_timer_from_isr();
            driver_state = WAV_PLAYBACK_DRIVER_UNDERRUN;
        }

        return;
    }

    mz_read_set_from_isr(next_output_level);
    played_samples++;

    /*
        TCNT1 is measured after the direct READ update. Its variation is the
        observable ISR-entry jitter diagnostic; the fixed prologue cancels
        when max-min is displayed.
    */
    latency = TCNT1;

    if (latency < min_latency_ticks)
    {
        min_latency_ticks = latency;
    }

    if (latency > max_latency_ticks)
    {
        max_latency_ticks = latency;
    }

    /*
        Prefetch the following sample after the edge was emitted. This work
        does not move the current edge in time, and is bounded to packed-ring
        bit extraction plus a 16-bit sequence increment.
    */
    (void)wav_playback_fetch_next_sample();
    wav_playback_schedule_full_sample_period();
}
