#ifndef SD2CMT2_WAV_PLAYBACK_DRIVER_H
#define SD2CMT2_WAV_PLAYBACK_DRIVER_H

#include <stdbool.h>
#include <stdint.h>

/*
    The driver emits one prepared logical READ value for every WAV sample
    period. It does not parse WAV, access SD, or perform hysteresis.

    The source callback must be ISR-safe: it only dequeues one already
    prepared 0/1 sample from a lock-free SPSC buffer.
*/
typedef bool (*wav_playback_pop_sample_fn)(uint8_t *level);
typedef bool (*wav_playback_source_finished_fn)(void);

typedef enum
{
    WAV_PLAYBACK_DRIVER_STOPPED = 0,
    WAV_PLAYBACK_DRIVER_READY,
    WAV_PLAYBACK_DRIVER_RUNNING,
    WAV_PLAYBACK_DRIVER_PAUSED,
    WAV_PLAYBACK_DRIVER_FINISHED,
    WAV_PLAYBACK_DRIVER_UNDERRUN,
    WAV_PLAYBACK_DRIVER_BAD_RATE,
    WAV_PLAYBACK_DRIVER_BAD_ARGUMENT
} wav_playback_driver_state_t;

void wav_playback_driver_init(void);

bool wav_playback_driver_prepare(uint32_t sample_rate,
                                 wav_playback_pop_sample_fn pop_sample,
                                 wav_playback_source_finished_fn source_finished);

bool wav_playback_driver_start(void);
bool wav_playback_driver_pause(void);
bool wav_playback_driver_resume(void);

void wav_playback_driver_stop(void);

wav_playback_driver_state_t wav_playback_driver_get_state(void);
uint32_t wav_playback_driver_get_sample_rate(void);
uint8_t wav_playback_driver_get_read_pin(void);

/* Number of WAV samples already emitted to READ in the current session. */
uint32_t wav_playback_driver_get_played_samples(void);

/*
    Peak-to-peak variation of Timer1 ISR entry latency in CPU clock ticks.
    It measures scheduling jitter, not the intrinsic 362/363-tick fractional
    spacing required by 44.1 kHz from a 16 MHz clock.
*/
uint16_t wav_playback_driver_get_jitter_ticks(void);

#endif
